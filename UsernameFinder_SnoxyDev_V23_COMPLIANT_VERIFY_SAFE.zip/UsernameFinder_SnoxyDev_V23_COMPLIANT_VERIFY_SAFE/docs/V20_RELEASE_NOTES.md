# Username Finder V23 COMPLIANT VERIFY SAFE

## Ziel

V23 trennt lokale Kandidaten-Generierung komplett von echter Verifikation. Die App soll nicht mehr so wirken, als wuerde sie freie/vergebene Namen automatisch beweisen, wenn kein vertrauenswuerdiger Provider vorhanden ist.

## Neu

- Results-Tabelle zeigt nur noch echte Statuswerte: `VALID_VERIFIED`, `TAKEN_VERIFIED`, `INVALID_RULE`.
- `READY_FOR_PROVIDER`, `UNKNOWN` und lokale Predictions werden nicht mehr als normale Treffer angezeigt.
- Neuer Provider Gateway: `app/tools/ProviderGateway.ps1`.
- Echter Provider muss als `providers/OfficialProvider.ps1` installiert werden. Ohne diese Datei startet Official-Provider-Modus nicht und erzeugt keine Fake-Ergebnisse.
- Provider-Log: `%LocalAppData%\SnoxyDev\UsernameFinder\provider_gateway.log`.
- Discord loggt weiterhin nur `VALID_VERIFIED`.

## Warum kein eingebauter Plattform-Scraper?

Eine 100%-Aussage ueber frei/vergeben ist nur ueber eine erlaubte, vertrauenswuerdige Quelle moeglich. Unoffizielle Massenscrapes wuerden Fake-Hits, Sperren, Rate-Limits und Account-Enumeration-Risiken erzeugen.
