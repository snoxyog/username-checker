# Username Finder V23 COMPLIANT VERIFY SAFE

## Was neu ist

- Klarer Fokus: echte Checks sind nur `VALID_VERIFIED`, `TAKEN_VERIFIED` oder `INVALID_RULE`.
- Browser-Proof ist **manuell**: die App kann eine Profil-URL öffnen, aber keine automatisierten Browser-Worker gegen Plattformen starten.
- Discord-Bot-Token-Username-Enumeration ist nicht eingebaut. Zulässig sind nur importierte Proof-Daten oder eigene erlaubte/official Provider.
- Verbesserte Discord-Logs bleiben verified-only.
- Bessere Setup-/Provider-Diagnose und stabiler versionierter Installationspfad.

## Warum kein Browser-Massencheck?

Automatisierte Browser-Abfragen gegen Instagram/TikTok/Telegram/Snapchat/Discord sind instabil, riskieren Sperren/Rate-Limits und liefern oft falsche Ergebnisse durch Login-Walls, Captchas, Caches, regionale Unterschiede und Anti-Automation. V23 trennt deshalb sicher: Kandidaten/Format lokal, echte Wahrheit nur durch Proof/Provider.
