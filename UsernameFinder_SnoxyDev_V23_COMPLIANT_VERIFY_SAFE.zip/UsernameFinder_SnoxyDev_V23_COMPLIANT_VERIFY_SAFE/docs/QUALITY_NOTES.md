# Quality Notes

V18 focuses on stability instead of fake availability. The local engine is intentionally only a candidate generator plus platform-rule validator. Real free/taken status requires a trusted source: verified CSV import, manual proof, or an official/allowed provider adapter.

Key reliability changes:

- versioned install folder prevents locked-file setup failures
- HTA runtime avoids .NET/WPF/WinForms startup issues
- PNG asset fallback avoids broken banner/avatar rendering in HTA
- PowerShell broker avoids HTA network permission errors
- persistent caches avoid repeated local handling of checked/invalid/taken/valid names
- UI micro-bursts keep the app responsive under high local generation speed
- Discord duplicate guard prevents repeated logs for the same verified name
