# Username Finder V23 COMPLIANT VERIFY SAFE

## Was V23 wirklich anders macht

V23 stellt den Einzel-Check in den Mittelpunkt: Plattform + Username eingeben, `CHECK USERNAME` drücken, und die App gibt nur noch ehrliche Status aus:

- `INVALID_RULE`: lokale Plattformregel lehnt den Namen ab
- `VALID_VERIFIED`: eine vertrauenswürdige Quelle bestätigt frei/verwendbar
- `TAKEN_VERIFIED`: eine vertrauenswürdige Quelle bestätigt vergeben/nicht verfügbar
- `UNKNOWN_UNVERIFIED`: keine vertrauenswürdige Quelle hat einen Beweis geliefert

## Warum nicht jeder generierte Name automatisch VALID/TAKEN wird

Ohne offiziellen/erlaubten Provider oder importierte Proof-Daten gibt es keinen zuverlässigen Beweis. V23 macht deshalb keine Fake-Ergebnisse.

## Provider

Der eingebaute Local Trusted Database Provider prüft gegen deine lokalen Proof-Daten:

- `trusted_verify_database.csv`
- `verified_available_usernames.tsv`
- `taken_usernames.tsv`
- `invalid_usernames.tsv`

Er macht keine versteckten Plattform-Scrapes.

## Discord

Discord loggt nur `VALID_VERIFIED`.
