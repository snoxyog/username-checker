# Discord Webhook Broker (V18)

V17 sent webhook requests directly from HTA/MSXML. On many Windows systems that causes `Erlaubnis verweigert` / Access denied. V18 writes a JSON payload to a local outbox and starts `app/tools/DiscordWebhookBroker.ps1`.

The broker uses Windows PowerShell 5.1, TLS 1.2/1.3 when available, retries, 429 handling, and writes clear status lines to `%LocalAppData%\SnoxyDev\UsernameFinder\webhook_results.log`.

Only `VALID_VERIFIED` rows are queued for Discord. Local predictions, local format checks, and generated usernames are never logged as hits.
