# Changelog

## V23 COMPLIANT VERIFY SAFE

- App vollständig auf HTA umgebaut.
- Kein .NET/WinForms/WPF-GUI-Startfehler mehr.
- Reiner User-Scope Installer.
- Versionierte Installationen.
- Instant Turbo Micro-Burst Engine.
- Verified-only Discord logging.
- Import-Verifikation für VALID/TAKEN/INVALID.
- Bessere Logs, Crash-Datei, Debug-Launcher.
