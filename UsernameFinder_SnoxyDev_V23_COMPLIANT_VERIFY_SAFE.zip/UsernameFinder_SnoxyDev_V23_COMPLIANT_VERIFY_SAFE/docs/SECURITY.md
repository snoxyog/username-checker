# Security

- Keine versteckten Downloads.
- Keine Admin-Rechte.
- Keine Systemweiten Änderungen.
- Keine echten Social-Media-Scrapes.
- Discord-Logs nur bei `VALID_VERIFIED`.
- @everyone/@here/Role-Pings sind optional und cooldown-geschützt.
- Webhook wird standardmäßig nicht gespeichert. Wenn Speichern aktiviert wird, wird er nur lokal obfuskiert gespeichert.

Hinweis: Obfuskierung ist kein starker Schutz wie DPAPI. Für maximale Sicherheit Webhook nicht speichern und nur pro Session eingeben.
