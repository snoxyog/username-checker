# Username Finder V23 COMPLIANT VERIFY SAFE

Diese Version ist auf eine Sache optimiert: einen Username sauber als `INVALID_RULE`, `VALID_VERIFIED`, `TAKEN_VERIFIED` oder `UNKNOWN_UNVERIFIED` einordnen.

## Installation

1. ZIP vollständig entpacken
2. `START_INSTALL.cmd` starten
3. App installiert sich nach `%LocalAppData%\SnoxyDev\UsernameFinder`
4. App startet automatisch

## Anforderungen

Das Setup prüft automatisch:

- Windows HTA Runtime: `%WINDIR%\System32\mshta.exe`
- Windows PowerShell 5.1
- Schreibrechte in `%LocalAppData%`
- App, Discord Broker, Provider Gateway und Local Trusted Provider

Es werden keine Admin-Rechte, keine Downloads, kein SDK und kein Compiler benötigt.

## Richtig prüfen

Nutze links `Single TrueCheck`:

1. Plattform wählen
2. Username eingeben
3. `CHECK USERNAME` drücken

Ergebnis:

- `INVALID_RULE`: der Name kann auf dieser Plattform so nicht funktionieren
- `VALID_VERIFIED`: vertrauenswürdig als frei bestätigt
- `TAKEN_VERIFIED`: vertrauenswürdig als vergeben bestätigt
- `UNKNOWN_UNVERIFIED`: kein Beweis vorhanden

## Warum UNKNOWN?

Eine App kann aus lokalen Regeln nicht wissen, ob ein Name auf Discord/TikTok/Instagram/etc. frei ist. Dafür braucht sie eine erlaubte Quelle: importierte Proof-Daten, lokalen Trusted Cache oder einen offiziellen/erlaubten Provider.

## Logs

- `%LocalAppData%\SnoxyDev\UsernameFinder\install.log`
- `%LocalAppData%\SnoxyDev\UsernameFinder\selftest.log`
- `%LocalAppData%\SnoxyDev\UsernameFinder\app.log`
- `%LocalAppData%\SnoxyDev\UsernameFinder\crash.log`
- `%LocalAppData%\SnoxyDev\UsernameFinder\webhook_results.log`
- `%LocalAppData%\SnoxyDev\UsernameFinder\provider_gateway.log`


## V23 Hinweis

Automatisierte Browser-Massenchecks und Discord-Bot-Token-Username-Enumeration sind nicht enthalten. Die App unterstützt manuelle Browser-Prüfung und echte Provider-/Import-Prüfung.
