# V23 Installer Design

- User-scope only: `%LocalAppData%`
- Keine Admin-Rechte
- Keine Downloads
- Keine SDK-/Compiler-Abhaengigkeit
- Versionierte Installation: `versions\v22_yyyyMMdd_HHmmss_pid`
- Alte laufende HTA-App wird vor Installation sauber beendet
- Robuste Datei-Kopie mit Retry
- Selftest: `selftest.log`
- Debugstart: `Start_UsernameFinder_DEBUG.cmd`
- Repair: `Repair_Install.cmd`
