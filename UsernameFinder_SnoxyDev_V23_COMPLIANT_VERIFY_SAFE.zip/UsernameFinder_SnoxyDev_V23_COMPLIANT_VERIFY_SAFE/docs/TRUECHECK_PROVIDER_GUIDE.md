# TrueCheck Provider Guide

Damit die App echte `VALID_VERIFIED` oder `TAKEN_VERIFIED` Ergebnisse liefern kann, braucht sie einen erlaubten Provider. Dieser muss als `providers/OfficialProvider.ps1` installiert sein und pro Plattform+Username einen nachweisbaren Status zurückgeben.

## Provider-Ausgabe

JSON pro Check:

```json
{"platform":"Discord","username":"name","status":"VALID_VERIFIED","source":"Allowed official provider","latencyMs":123,"score":99,"reason":"Provider proof"}
```

Erlaubte Status:

- `VALID_VERIFIED`
- `TAKEN_VERIFIED`
- `INVALID_RULE`
- `UNKNOWN_UNVERIFIED`

Alles andere wird von der App als `UNKNOWN_UNVERIFIED` behandelt.
