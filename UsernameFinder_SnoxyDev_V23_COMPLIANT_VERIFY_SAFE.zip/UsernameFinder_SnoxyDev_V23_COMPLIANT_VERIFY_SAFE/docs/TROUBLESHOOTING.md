# Troubleshooting

## Setup geht, App öffnet nicht

1. Starte:
   `%LocalAppData%\SnoxyDev\UsernameFinder\Start_UsernameFinder_DEBUG.cmd`
2. Prüfe:
   `%LocalAppData%\SnoxyDev\UsernameFinder\install.log`
   `%LocalAppData%\SnoxyDev\UsernameFinder\app.log`
   `%LocalAppData%\SnoxyDev\UsernameFinder\crash.log`

## mshta.exe blockiert

Manche Firmen-/Security-Setups deaktivieren HTA. Dann kann die App nicht als HTA laufen. Das Setup ändert keine Richtlinien.

## Alte Version läuft noch

V17 nutzt versionierte Ordner und überschreibt alte laufende Ordner nicht. Alte Fenster einfach schließen.
