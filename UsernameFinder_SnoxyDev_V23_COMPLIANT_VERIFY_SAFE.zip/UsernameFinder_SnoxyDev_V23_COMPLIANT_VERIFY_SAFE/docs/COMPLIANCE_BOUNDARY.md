# Compliance Boundary

Nicht eingebaut:

- automatisierte Browser-Worker, die massenhaft Profilseiten abrufen
- Proxy-/Captcha-/Rate-Limit-Umgehung
- Discord-Bot-Token-Enumeration von Usernames
- Fake-Valid-Ergebnisse aus lokalen Predictions

Eingebaut:

- lokaler Syntaxcheck
- Trusted CSV/TSV Datenbank
- LocalTrustedDatabaseProvider
- ProviderGateway für erlaubte offizielle Provider
- manuelles Öffnen einer Profil-URL
- verified-only Discord-Logging
