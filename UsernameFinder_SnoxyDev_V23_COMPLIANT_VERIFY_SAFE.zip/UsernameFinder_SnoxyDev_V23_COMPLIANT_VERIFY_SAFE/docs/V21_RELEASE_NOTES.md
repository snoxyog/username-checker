# Username Finder V23 COMPLIANT VERIFY SAFE

## Fokus

V23 repariert den Installer grundlegend. Statt `xcopy` und fehleranfaelligen Batch-Kopien nutzt das Setup jetzt einen robusten PowerShell-Installer mit Retry-Copy, Selftest, versionierten Ordnern, Prozess-Schliessen alter HTA-Instanzen und klaren Logs.

## Requirements

Die App ist bewusst lokal/portable gebaut und benoetigt keine Downloads, keine Admin-Rechte und kein SDK. Das Setup prueft automatisch:

- `%WINDIR%\System32\mshta.exe` fuer die HTA-Windows-App
- `%WINDIR%\System32\WindowsPowerShell\v1.0\powershell.exe` fuer Setup, Discord Broker und Provider Gateway
- Schreibrechte in `%LocalAppData%\SnoxyDev\UsernameFinder`

Falls eine Windows-Komponente per Unternehmensrichtlinie deaktiviert ist, kann das Setup sie ohne Admin/Internet nicht heimlich aktivieren.

## Provider

V23 installiert einen sicheren `Local Trusted Database Provider` als `providers/OfficialProvider.ps1`. Dieser prueft exakt gegen deine importierten/verifizierten lokalen Daten:

- `trusted_verify_database.csv`
- `verified_available_usernames.tsv`
- `taken_usernames.tsv`
- `invalid_usernames.tsv`

Er macht keine versteckten Plattform-Scrapes und gibt fuer unbekannte Namen `UNKNOWN_UNVERIFIED` zurueck.

## Discord

Discord loggt weiterhin nur `VALID_VERIFIED`. Keine lokalen Kandidaten, keine Predictions, keine Fake-Hits.
