# Provider Gateway

`app/tools/ProviderGateway.ps1` verarbeitet Batches mit Kandidaten und ruft `providers/OfficialProvider.ps1` auf.

## Input

TSV mit Header:

```text
Platform	Username
Discord	example
```

## Output

TSV mit Header:

```text
Platform	Username	Status	Source	LatencyMs	Score	Reason
```

Erlaubte Statuswerte:

- `VALID_VERIFIED`
- `TAKEN_VERIFIED`
- `INVALID_RULE`
- `UNKNOWN_UNVERIFIED`

Nur `VALID_VERIFIED` wird an Discord geloggt.
