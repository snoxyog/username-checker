# Username Finder V23 COMPLIANT VERIFY SAFE

## Wichtigste Fixes

- Discord Broker-Pfade werden jetzt korrekt beim App-Start initialisiert.
- `Webhook`-Karte zeigt jetzt echte Zustände: `ready`, `no/invalid url`, `broker missing`, `no powershell`.
- Webhook Regex akzeptiert auch `/api/v10/webhooks/...`, Query-Strings und Token mit Punkten.
- Discord-Versand nutzt UTF-8 Bytes, TLS 1.2/1.3 und `?wait=true`, damit HTTP-Ergebnisse sauberer sind.
- Neuer Diagnose-Button erklärt 400/401/403/404/429 Fehler.
- Bessere Discord Embeds mit Verification ID, Quelle, Latency, Score, Engine Snapshot und Safety Gate.
- UI Tools Panel mit Data Folder, Webhook Log, Self-Diagnostics und Template-Erstellung.

## Safety

Die App macht weiterhin keine versteckten Social-Media-Scrapes und loggt nur `VALID_VERIFIED`. Lokale Kandidaten werden nicht als frei behauptet.
