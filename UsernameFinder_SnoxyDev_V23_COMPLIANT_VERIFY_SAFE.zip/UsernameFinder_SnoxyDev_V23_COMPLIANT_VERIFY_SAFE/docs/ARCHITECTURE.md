# Architecture

- `START_INSTALL.cmd` calls `installer\install.cmd`.
- Installer copies files into `%LocalAppData%\SnoxyDev\UsernameFinder\versions\v22_*`.
- Launcher runs `mshta.exe UsernameFinder.hta`.
- App data is stored in `%LocalAppData%\SnoxyDev\UsernameFinder\data`.
- Caches use TSV for simple recovery and inspection.
- UI loop uses micro-bursts to prevent freezing.
