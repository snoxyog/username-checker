# Browser Proof Mode

V23 kann für TikTok, Instagram, Telegram und Snapchat eine Profil-URL für einen einzelnen eingegebenen Namen öffnen.

Das ist bewusst **kein automatisierter Browser-Checker**. Nach manueller Sichtprüfung kannst du den Namen als `VALID_VERIFIED` oder `TAKEN_VERIFIED` markieren. Erst `VALID_VERIFIED` wird an Discord geloggt.

Discord hat keine zuverlässige öffentliche Profil-URL für Username-Verfügbarkeit. Verwende dafür nur Import/Trusted DB oder einen erlaubten offiziellen Provider.
