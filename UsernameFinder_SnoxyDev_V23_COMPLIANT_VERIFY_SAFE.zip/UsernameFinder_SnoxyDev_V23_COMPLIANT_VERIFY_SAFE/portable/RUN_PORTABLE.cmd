@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0.."
if not exist "app\UsernameFinder.hta" (
  echo App missing.
  pause
  exit /b 2
)
start "" "%SystemRoot%\System32\mshta.exe" "%CD%\app\UsernameFinder.hta"
