@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0.."
echo Starting portable debug: %CD%\app\UsernameFinder.hta
"%SystemRoot%\System32\mshta.exe" "%CD%\app\UsernameFinder.hta"
echo.
echo Logs: %LocalAppData%\SnoxyDev\UsernameFinder\app.log
pause
