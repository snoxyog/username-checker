@echo off
start "" "%~dp0UsernameFinder_Fallback.html"
