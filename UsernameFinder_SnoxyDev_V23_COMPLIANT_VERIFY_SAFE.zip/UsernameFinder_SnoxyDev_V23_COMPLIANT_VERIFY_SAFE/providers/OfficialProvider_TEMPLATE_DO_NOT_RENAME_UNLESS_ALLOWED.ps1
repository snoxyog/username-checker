<#
Username Finder V23 OfficialProvider TEMPLATE
Rename/copy this file to OfficialProvider.ps1 only when you connect an official/allowed verification source.
Do not scrape websites, bypass rate limits, or automate account enumeration.

Required output JSON:
{
  "platform":"Discord",
  "username":"example",
  "status":"VALID_VERIFIED | TAKEN_VERIFIED | INVALID_RULE | UNKNOWN_UNVERIFIED",
  "source":"Official/allowed source name",
  "latencyMs":123,
  "score":99,
  "reason":"short explanation"
}
#>
param([Parameter(Mandatory=$true)][string]$Platform,[Parameter(Mandatory=$true)][string]$Username)
$sw=[Diagnostics.Stopwatch]::StartNew()
# Replace this placeholder with calls to your official/allowed source.
$sw.Stop()
[PSCustomObject]@{
  platform=$Platform
  username=$Username
  status='UNKNOWN_UNVERIFIED'
  source='Template only - no official provider configured'
  latencyMs=$sw.ElapsedMilliseconds
  score=0
  reason='Install a real allowed provider before claiming VALID/TAKEN.'
} | ConvertTo-Json -Compress
