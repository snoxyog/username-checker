<#
OfficialProvider_Template.ps1
Return schema expected by Username Finder:
{
  "platform": "Discord",
  "username": "example",
  "status": "VALID_VERIFIED | TAKEN_VERIFIED | INVALID_RULE | UNKNOWN_UNVERIFIED",
  "source": "Official API / Manual Proof / Trusted Import",
  "latencyMs": 123,
  "score": 99,
  "reason": "short reason"
}

Only connect official/allowed APIs here. Do not scrape or bypass platform rate limits.
#>
param([string]$Platform,[string]$Username)
$sw = [Diagnostics.Stopwatch]::StartNew()
# Placeholder: no real network verification is performed in the template.
$sw.Stop()
[PSCustomObject]@{
  platform=$Platform
  username=$Username
  status='UNKNOWN_UNVERIFIED'
  source='Provider template only'
  latencyMs=$sw.ElapsedMilliseconds
  score=0
  reason='No official provider configured'
} | ConvertTo-Json -Compress
