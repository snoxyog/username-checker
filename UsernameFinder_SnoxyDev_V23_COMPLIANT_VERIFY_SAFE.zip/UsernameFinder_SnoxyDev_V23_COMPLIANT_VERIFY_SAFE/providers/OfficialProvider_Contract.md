# Official Provider Contract

Username Finder V23 does not scrape social platforms. Real availability must come from a trusted source.

Accepted CSV columns:

```csv
Platform,Username,Status,Source,LatencyMs,Score
Discord,snoxy_test,VALID_VERIFIED,Official/allowed provider,120,99
TikTok,abc,TAKEN_VERIFIED,Official/allowed provider,80,0
```

Accepted status values:
- `VALID_VERIFIED`, `VALID`, `AVAILABLE`, `FREE`
- `TAKEN_VERIFIED`, `TAKEN`, `UNAVAILABLE`, `USED`
- `INVALID_RULE`, `INVALID`

Only `VALID_VERIFIED` entries are sent to Discord.
