<#
Username Finder V23 Local Trusted Database Provider
Safe default provider. It does NOT contact Discord/TikTok/Instagram/Telegram/Snapchat.
It returns VALID_VERIFIED / TAKEN_VERIFIED / INVALID_RULE only when your trusted local CSV/TSV data contains that exact platform+username.
Unknown names stay UNKNOWN_UNVERIFIED. This avoids fake hits and still lets the app do true lookups from imported proof data.
#>
param([Parameter(Mandatory=$true)][string]$Platform,[Parameter(Mandatory=$true)][string]$Username)
$ErrorActionPreference = 'SilentlyContinue'
$sw=[Diagnostics.Stopwatch]::StartNew()
function Key([string]$p,[string]$u){ return (($p.Trim().ToLowerInvariant()) + ':' + ($u.Trim().ToLowerInvariant())) }
function Clean([object]$v){ if($null -eq $v){''}else{[string]$v} }
if(-not $global:UFTrustedLoaded){
  $global:UFTrustedLoaded=$true
  $global:UFTrusted=@{}
  $data=Join-Path $env:LOCALAPPDATA 'SnoxyDev\UsernameFinder\data'
  function Add-Result([string]$p,[string]$u,[string]$status,[string]$source,[string]$reason){
    if([string]::IsNullOrWhiteSpace($p) -or [string]::IsNullOrWhiteSpace($u)){ return }
    $s=$status.ToUpperInvariant()
    if($s -in @('AVAILABLE','FREE','VALID')){ $s='VALID_VERIFIED' }
    elseif($s -in @('TAKEN','USED','UNAVAILABLE')){ $s='TAKEN_VERIFIED' }
    elseif($s -in @('INVALID')){ $s='INVALID_RULE' }
    if($s -notin @('VALID_VERIFIED','TAKEN_VERIFIED','INVALID_RULE')){ return }
    $global:UFTrusted[(Key $p $u)] = [pscustomobject]@{ platform=$p; username=$u; status=$s; source=$source; reason=$reason }
  }
  $csv = Join-Path $data 'trusted_verify_database.csv'
  if(Test-Path -LiteralPath $csv){
    foreach($r in (Import-Csv -LiteralPath $csv)){
      Add-Result (Clean $r.Platform) (Clean $r.Username) (Clean $r.Status) ($(if($r.Source){$r.Source}else{'trusted_verify_database.csv'})) ($(if($r.Reason){$r.Reason}else{'Trusted local database entry'}))
    }
  }
  $maps = @(
    @{file='verified_available_usernames.tsv'; status='VALID_VERIFIED'; source='verified_available_usernames.tsv'},
    @{file='taken_usernames.tsv'; status='TAKEN_VERIFIED'; source='taken_usernames.tsv'},
    @{file='invalid_usernames.tsv'; status='INVALID_RULE'; source='invalid_usernames.tsv'}
  )
  foreach($m in $maps){
    $path=Join-Path $data $m.file
    if(Test-Path -LiteralPath $path){
      foreach($line in [IO.File]::ReadLines($path)){
        if([string]::IsNullOrWhiteSpace($line)){ continue }
        $parts=$line -split "`t"
        if($parts.Count -ge 2){ Add-Result $parts[0] $parts[1] $m.status $m.source 'Trusted local cache entry' }
      }
    }
  }
}
$k=Key $Platform $Username
$sw.Stop()
if($global:UFTrusted.ContainsKey($k)){
  $r=$global:UFTrusted[$k]
  [pscustomobject]@{ platform=$Platform; username=$Username; status=$r.status; source=$r.source; latencyMs=$sw.ElapsedMilliseconds; score=99; reason=$r.reason } | ConvertTo-Json -Compress
} else {
  [pscustomobject]@{ platform=$Platform; username=$Username; status='UNKNOWN_UNVERIFIED'; source='Local trusted DB provider'; latencyMs=$sw.ElapsedMilliseconds; score=0; reason='No trusted local proof for this exact username.' } | ConvertTo-Json -Compress
}
