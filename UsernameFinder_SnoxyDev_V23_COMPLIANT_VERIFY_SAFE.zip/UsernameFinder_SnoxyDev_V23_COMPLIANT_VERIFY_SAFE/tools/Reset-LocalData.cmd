@echo off
setlocal
echo This resets local Username Finder cache/settings, not the installed app.
set /p OK=Type RESET to continue: 
if /i not "%OK%"=="RESET" exit /b 0
rmdir /s /q "%LocalAppData%\SnoxyDev\UsernameFinder\data" >nul 2>nul
echo Done.
pause
