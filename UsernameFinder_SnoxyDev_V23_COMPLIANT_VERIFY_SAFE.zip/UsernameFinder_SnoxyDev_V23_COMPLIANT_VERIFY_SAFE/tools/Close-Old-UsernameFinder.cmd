@echo off
echo Closing old Username Finder HTA windows if any...
taskkill /IM mshta.exe /FI "WINDOWTITLE eq Username Finder*" >nul 2>nul
echo Done.
pause
