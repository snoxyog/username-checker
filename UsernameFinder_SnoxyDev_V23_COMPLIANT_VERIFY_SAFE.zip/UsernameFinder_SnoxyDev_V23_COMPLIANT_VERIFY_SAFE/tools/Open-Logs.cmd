@echo off
set "ROOT=%LocalAppData%\SnoxyDev\UsernameFinder"
if not exist "%ROOT%" mkdir "%ROOT%"
explorer.exe "%ROOT%"
