@echo off
set "ROOT=%LocalAppData%\SnoxyDev\UsernameFinder"
if not exist "%ROOT%\webhook_results.log" echo No webhook results yet.>"%ROOT%\webhook_results.log"
start notepad "%ROOT%\webhook_results.log"
