@echo off
setlocal EnableExtensions
set "DATA=%LocalAppData%\SnoxyDev\UsernameFinder\data"
if not exist "%DATA%" mkdir "%DATA%" >nul 2>nul
set "CSV=%DATA%\trusted_verify_database.csv"
if not exist "%CSV%" (
  >"%CSV%" echo Platform,Username,Status,Source,Reason
  >>"%CSV%" echo Discord,snoxy,VALID_VERIFIED,manual proof,example available proof
  >>"%CSV%" echo TikTok,abc,TAKEN_VERIFIED,allowed provider,example taken proof
)
start notepad "%CSV%"
