@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
title Username Finder V23 COMPLIANT VERIFY Setup - Snoxy.dev
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
  echo [ERROR] Windows PowerShell 5.1 wurde nicht gefunden.
  echo Diese eingebaute Windows-Komponente ist fuer Setup, Discord Broker und Provider Gateway notwendig.
  echo Bitte Windows PowerShell aktivieren oder die portable Browser-Fallback-Datei nutzen.
  pause
  exit /b 11
)
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install-UsernameFinder.ps1"
set "CODE=%ERRORLEVEL%"
if not "%CODE%"=="0" (
  echo.
  echo [FEHLER] Setup fehlgeschlagen. Code: %CODE%
  echo Log: %LocalAppData%\SnoxyDev\UsernameFinder\install.log
  echo.
  pause
  exit /b %CODE%
)
echo.
echo [OK] Setup abgeschlossen.
pause
exit /b 0
