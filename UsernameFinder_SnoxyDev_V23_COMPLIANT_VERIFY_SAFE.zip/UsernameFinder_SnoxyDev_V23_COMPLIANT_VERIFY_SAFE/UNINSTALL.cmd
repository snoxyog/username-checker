@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
echo Username Finder uninstall - user scope only.
set "ROOT=%LocalAppData%\SnoxyDev\UsernameFinder"
if exist "%ROOT%" (
  echo Removing %ROOT%
  rmdir /s /q "%ROOT%"
)
del "%USERPROFILE%\Desktop\Username Finder.lnk" >nul 2>nul
rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Snoxy.dev" >nul 2>nul
echo Done.
pause
