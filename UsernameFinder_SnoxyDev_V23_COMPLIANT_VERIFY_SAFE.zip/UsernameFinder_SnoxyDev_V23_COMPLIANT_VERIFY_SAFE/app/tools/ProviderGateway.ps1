<#
Username Finder V23 Provider Gateway
This broker runs outside HTA and calls an installed, official/allowed provider adapter.
It never scrapes anything by itself. Without providers\OfficialProvider.ps1, it refuses to fake results.

Input TSV:  Platform<TAB>Username
Output TSV: Platform<TAB>Username<TAB>Status<TAB>Source<TAB>LatencyMs<TAB>Score<TAB>Reason
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$BatchFile,
  [Parameter(Mandatory=$true)][string]$ResultFile,
  [Parameter(Mandatory=$true)][string]$ProviderFile,
  [Parameter(Mandatory=$true)][string]$LogFile
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
function Write-Log([string]$Level,[string]$Message){
  try {
    $dir = Split-Path -Parent $LogFile
    if($dir -and -not (Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Add-Content -LiteralPath $LogFile -Encoding UTF8 -Value ('[{0:yyyy-MM-ddTHH:mm:ss.fff}] [{1}] {2}' -f (Get-Date),$Level,$Message)
  } catch {}
}
function Clean-Field([object]$v){
  if($null -eq $v){ return '' }
  return ([string]$v).Replace("`t",' ').Replace("`r",' ').Replace("`n",' ')
}
try {
  Write-Log 'INFO' "Gateway start. Batch=$BatchFile Provider=$ProviderFile"
  if(-not (Test-Path -LiteralPath $BatchFile)){ throw "Batch file missing: $BatchFile" }
  if(-not (Test-Path -LiteralPath $ProviderFile)){
    Write-Log 'ERROR' "Provider adapter missing. Refusing to fake results: $ProviderFile"
    'Platform' + "`t" + 'Username' + "`t" + 'Status' + "`t" + 'Source' + "`t" + 'LatencyMs' + "`t" + 'Score' + "`t" + 'Reason' | Set-Content -LiteralPath $ResultFile -Encoding UTF8
    exit 0
  }
  $rows = Import-Csv -LiteralPath $BatchFile -Delimiter "`t"
  $out = New-Object System.Collections.Generic.List[string]
  $out.Add('Platform' + "`t" + 'Username' + "`t" + 'Status' + "`t" + 'Source' + "`t" + 'LatencyMs' + "`t" + 'Score' + "`t" + 'Reason')
  $count = 0
  foreach($row in $rows){
    $platform = [string]$row.Platform
    $username = [string]$row.Username
    if([string]::IsNullOrWhiteSpace($platform) -or [string]::IsNullOrWhiteSpace($username)){ continue }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
      $raw = & $ProviderFile -Platform $platform -Username $username
      $sw.Stop()
      $obj = $null
      if($raw -is [string]) { $obj = $raw | ConvertFrom-Json } else { $obj = $raw }
      $status = ([string]$obj.status).ToUpperInvariant()
      if($status -notin @('VALID_VERIFIED','TAKEN_VERIFIED','INVALID_RULE','UNKNOWN_UNVERIFIED')){
        $status = 'UNKNOWN_UNVERIFIED'
      }
      $source = if($obj.source){ [string]$obj.source } else { 'OfficialProvider.ps1' }
      $latency = if($obj.latencyMs -ne $null){ [int]$obj.latencyMs } else { [int]$sw.ElapsedMilliseconds }
      $score = if($obj.score -ne $null){ [int]$obj.score } else { if($status -eq 'VALID_VERIFIED'){99}else{0} }
      $reason = if($obj.reason){ [string]$obj.reason } else { 'Provider result' }
      $out.Add((Clean-Field $platform) + "`t" + (Clean-Field $username) + "`t" + (Clean-Field $status) + "`t" + (Clean-Field $source) + "`t" + $latency + "`t" + $score + "`t" + (Clean-Field $reason))
      $count++
    } catch {
      $sw.Stop()
      Write-Log 'WARN' "Provider failed for $platform/$username : $($_.Exception.Message)"
      $out.Add((Clean-Field $platform) + "`t" + (Clean-Field $username) + "`tUNKNOWN_UNVERIFIED`tProvider error`t" + [int]$sw.ElapsedMilliseconds + "`t0`t" + (Clean-Field $_.Exception.Message))
    }
  }
  $dir = Split-Path -Parent $ResultFile
  if($dir -and -not (Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $out | Set-Content -LiteralPath $ResultFile -Encoding UTF8
  Remove-Item -LiteralPath $BatchFile -Force -ErrorAction SilentlyContinue
  Write-Log 'OK' "Gateway done. Rows=$count Result=$ResultFile"
  exit 0
} catch {
  Write-Log 'ERROR' $_.Exception.Message
  try {
    'Platform' + "`t" + 'Username' + "`t" + 'Status' + "`t" + 'Source' + "`t" + 'LatencyMs' + "`t" + 'Score' + "`t" + 'Reason' | Set-Content -LiteralPath $ResultFile -Encoding UTF8
  } catch {}
  exit 1
}
