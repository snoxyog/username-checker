<#
Username Finder V23 Discord Webhook Broker
Purpose: reliable Discord delivery outside HTA/MSXML.
No scraping, no username checks. It only sends already-verified app events.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$WebhookFile,
  [Parameter(Mandatory=$true)][string]$PayloadFile,
  [Parameter(Mandatory=$true)][string]$ResultLog,
  [string]$Label = 'discord',
  [switch]$DeleteWebhookFile
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-Result {
  param([string]$Level,[string]$Message)
  try {
    $dir = Split-Path -Parent $ResultLog
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $line = '[{0:yyyy-MM-ddTHH:mm:ss.fff}] [{1}] [{2}] {3}' -f (Get-Date), $Level, $Label, $Message
    Add-Content -LiteralPath $ResultLog -Value $line -Encoding UTF8
  } catch { }
}
function Read-HttpBody { param($Response)
  try {
    if ($null -eq $Response) { return '' }
    $stream = $Response.GetResponseStream()
    if ($null -eq $stream) { return '' }
    $reader = New-Object System.IO.StreamReader($stream)
    return $reader.ReadToEnd()
  } catch { return '' }
}
function Normalize-WebhookUri { param([string]$Uri)
  $u = $Uri.Trim()
  if ($u -notmatch '^https://(discord(app)?\.com|canary\.discord(app)?\.com|ptb\.discord(app)?\.com)/api/(v\d+/)?webhooks/\d+/[A-Za-z0-9_\-.]+(\?.*)?$') {
    throw 'Discord webhook URL failed validation. Copy the complete URL from Discord integrations.'
  }
  if ($u -match '\?') {
    if ($u -notmatch '[?&]wait=') { return $u + '&wait=true' }
    return $u
  }
  return $u + '?wait=true'
}
function Invoke-DiscordPost { param([string]$Uri,[string]$Json)
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($Json)
  try {
    $response = Invoke-WebRequest -Uri $Uri -Method Post -ContentType 'application/json; charset=utf-8' -Body $bytes -UseBasicParsing -TimeoutSec 30
    return @{ StatusCode=[int]$response.StatusCode; Body=($response.Content | Out-String) }
  } catch {
    $statusCode = $null; $body = ''
    try { $statusCode = [int]$_.Exception.Response.StatusCode } catch {}
    try { $body = Read-HttpBody -Response $_.Exception.Response } catch {}
    throw [PSCustomObject]@{ Message=$_.Exception.Message; StatusCode=$statusCode; Body=$body }
  }
}

try {
  Write-Result 'INFO' "Broker started. PowerShell=$($PSVersionTable.PSVersion) User=$env:USERNAME"
  if (-not (Test-Path -LiteralPath $WebhookFile)) { throw "Webhook file not found: $WebhookFile" }
  if (-not (Test-Path -LiteralPath $PayloadFile)) { throw "Payload file not found: $PayloadFile" }

  $webhookRaw = (Get-Content -LiteralPath $WebhookFile -Raw).Trim()
  $webhook = Normalize-WebhookUri -Uri $webhookRaw
  $payload = Get-Content -LiteralPath $PayloadFile -Raw
  if ([string]::IsNullOrWhiteSpace($payload)) { throw 'Payload is empty.' }
  try { $null = $payload | ConvertFrom-Json } catch { throw "Payload JSON is invalid: $($_.Exception.Message)" }

  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    if ([Enum]::GetNames([Net.SecurityProtocolType]) -contains 'Tls13') { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls13 }
  } catch { }

  $maxAttempts = 5
  for ($attempt=1; $attempt -le $maxAttempts; $attempt++) {
    try {
      $result = Invoke-DiscordPost -Uri $webhook -Json $payload
      if ($result.StatusCode -ge 200 -and $result.StatusCode -lt 300) {
        Write-Result 'OK' "Delivered to Discord. HTTP=$($result.StatusCode). Payload=$PayloadFile"
        Remove-Item -LiteralPath $PayloadFile -Force -ErrorAction SilentlyContinue
        if ($DeleteWebhookFile) { Remove-Item -LiteralPath $WebhookFile -Force -ErrorAction SilentlyContinue }
        exit 0
      }
      Write-Result 'WARN' "Discord returned HTTP=$($result.StatusCode) attempt=$attempt body=$($result.Body)"
    } catch {
      $err = $_.Exception
      $statusCode = $null; $body = ''
      try { $statusCode = $_.TargetObject.StatusCode } catch {}
      try { $body = $_.TargetObject.Body } catch {}
      if (-not $statusCode) { try { $statusCode = $err.StatusCode } catch {} }
      if (-not $body) { try { $body = $err.Body } catch {} }
      if ($statusCode -eq 429) {
        $delayMs = 1500
        try { $j = $body | ConvertFrom-Json; if ($j.retry_after) { $delayMs = [int]([double]$j.retry_after * 1000) } } catch {}
        Write-Result 'WARN' "Rate limited by Discord. attempt=$attempt waitMs=$delayMs body=$body"
        Start-Sleep -Milliseconds ([Math]::Max(250,[Math]::Min($delayMs,15000)))
        continue
      }
      if ($statusCode -eq 401 -or $statusCode -eq 404) { throw "Discord rejected webhook URL/token. HTTP=$statusCode Body=$body" }
      if ($statusCode -eq 403) { throw "Discord permission denied for webhook/channel. HTTP=403 Body=$body" }
      if ($statusCode -eq 400) { throw "Discord rejected payload. HTTP=400 Body=$body" }
      if ($attempt -lt $maxAttempts) {
        Write-Result 'WARN' "Attempt $attempt failed. HTTP=$statusCode Error=$($err.Message) Body=$body"
        Start-Sleep -Milliseconds (500 * $attempt)
        continue
      }
      throw "All attempts failed. HTTP=$statusCode Error=$($err.Message) Body=$body"
    }
  }
  throw 'Delivery loop ended without success.'
} catch {
  Write-Result 'ERROR' $_.Exception.Message
  exit 1
} finally {
  if ($DeleteWebhookFile) { Remove-Item -LiteralPath $WebhookFile -Force -ErrorAction SilentlyContinue }
}
