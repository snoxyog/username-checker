/* Username Finder V23 COMPLIANT VERIFY SAFE
   Runtime: Windows HTA / JScript IE11 compatible.
   Design goals: fast start, no .NET/SDK, no WPF/WinForms crash surface, no fake availability results.
   Safety: the local engine only creates and validates candidate formats. Discord logs require VALID_VERIFIED.
*/
var UF = {};
UF.version = 'V23 COMPLIANT VERIFY SAFE';
UF.developer = 'Snoxy.dev';
UF.fso = null;
UF.shell = null;
UF.appDir = '';
UF.installRoot = '';
UF.dataRoot = '';
UF.logFile = '';
UF.crashFile = '';
UF.settingsFile = '';
UF.webhookOutbox = '';
UF.webhookBroker = '';
UF.webhookResultFile = '';
UF.webhookTmpFile = '';
UF.webhookLastText = '';
UF.webhookTimer = null;
UF.running = false;
UF.tickTimer = null;
UF.uiTimer = null;
UF.statsTimer = null;
UF.lastGenerated = 0;
UF.lastRateMs = 0;
UF.sessionSeen = {};
UF.checkedCache = {};
UF.invalidCache = {};
UF.takenCache = {};
UF.validCache = {};
UF.loggedCache = {};
UF.pendingRows = [];
UF.pendingValidRows = [];
UF.exportRows = [];
UF.lastMentionMs = 0;
UF.noPlatformWarned = false;
UF.importedValidPending = [];
UF.counters = { generated:0, unknown:0, predicted:0, valid:0, taken:0, duplicates:0, invalid:0, logged:0, rate:0 };
UF.rules = {
  'Discord':   { min:2, max:32, lower:true, upper:false, digits:true, specials:'._', forceLower:true, mustStartLetter:false, noEndDot:true, noStartDot:true, noDoubleDot:true },
  'TikTok':    { min:2, max:24, lower:true, upper:true,  digits:true, specials:'._', forceLower:false, mustStartLetter:false, noEndDot:true, noStartDot:false, noDoubleDot:true },
  'Instagram': { min:1, max:30, lower:true, upper:true,  digits:true, specials:'._', forceLower:false, mustStartLetter:false, noEndDot:true, noStartDot:false, noDoubleDot:true },
  'Telegram':  { min:5, max:32, lower:true, upper:true,  digits:true, specials:'_',  forceLower:false, mustStartLetter:true,  noEndDot:false, noStartDot:false, noDoubleDot:false },
  'Snapchat':  { min:3, max:15, lower:true, upper:true,  digits:true, specials:'._', forceLower:false, mustStartLetter:true,  noEndDot:true, noStartDot:false, noDoubleDot:true }
};

function UF_boot(){
  try {
    UF_initRuntime();
    UF_bindContractText();
    UF_loadSettings();
    UF_loadCaches();
    UF_refreshCacheView();
    UF_applySettingsToUi();
    UF_log('OK', 'Username Finder ' + UF.version + ' booted in HTA runtime. No .NET, no SDK, no admin.');
    UF_log('SAFE', 'Truth gate active: Discord logs only VALID_VERIFIED entries from trusted cache/import/provider.');
    UF_updateCards();
    UF.uiTimer = window.setInterval(UF_flushUi, 80);
    UF.statsTimer = window.setInterval(UF_updateCards, 250);
    UF.webhookTimer = window.setInterval(UF_pollWebhookResults, 1200);
    document.getElementById('statusText').innerText = 'Ready — verified-only mode. Press INSTANT START or import verified CSV.';
    document.getElementById('pathsText').innerText = UF.dataRoot;
    if (UF_id('autoStart').checked) {
      window.setTimeout(function(){ UF_startEngine(); }, 250);
    }
  } catch(e) {
    UF_crash('Boot failed: ' + UF_err(e));
    alert('Username Finder konnte nicht sauber starten. Crash wurde geloggt:\n' + UF.crashFile + '\n\n' + UF_err(e));
  }
}
function UF_shutdown(){ try { UF_saveSettings(); } catch(e){} }
function UF_err(e){ try { return (e && (e.message || e.description)) ? (e.message || e.description) : String(e); } catch(x){ return 'unknown error'; } }
function UF_id(id){ return document.getElementById(id); }
function UF_nowMs(){ return new Date().getTime(); }
function UF_pad(n){ return n < 10 ? '0'+n : ''+n; }
function UF_time(){ var d=new Date(); return UF_pad(d.getHours())+':'+UF_pad(d.getMinutes())+':'+UF_pad(d.getSeconds())+'.'+('00'+d.getMilliseconds()).slice(-3); }
function UF_iso(){ var d=new Date(); return d.getFullYear()+'-'+UF_pad(d.getMonth()+1)+'-'+UF_pad(d.getDate())+'T'+UF_pad(d.getHours())+':'+UF_pad(d.getMinutes())+':'+UF_pad(d.getSeconds()); }
function UF_fmt(n){ var s=String(Math.floor(n)); return s.replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }
function UF_initRuntime(){
  UF.fso = new ActiveXObject('Scripting.FileSystemObject');
  UF.shell = new ActiveXObject('WScript.Shell');
  UF.appDir = UF_getAppDir();
  UF.installRoot = UF.shell.ExpandEnvironmentStrings('%LOCALAPPDATA%') + '\\SnoxyDev\\UsernameFinder';
  UF.dataRoot = UF.installRoot + '\\data';
  UF.ensureDir(UF.installRoot); UF.ensureDir(UF.dataRoot);
  UF.logFile = UF.installRoot + '\\app.log';
  UF.crashFile = UF.installRoot + '\\crash.log';
  UF.settingsFile = UF.dataRoot + '\\settings_v22.json';
  UF.webhookOutbox = UF.dataRoot + '\\webhook_outbox';
  UF.webhookBroker = UF.appDir + '\\tools\\DiscordWebhookBroker.ps1';
  UF.webhookResultFile = UF.installRoot + '\\webhook_results.log';
  UF.webhookTmpFile = UF.dataRoot + '\\webhook_current.tmp';
  UF.ensureDir(UF.webhookOutbox);
  try { if(!UF.fso.FileExists(UF.webhookResultFile)) UF_writeText(UF.webhookResultFile, '['+UF_iso()+'] [INFO] Webhook result log created by V19.\r\n'); } catch(_e){}
  UF.lastRateMs = UF_nowMs();
}
function UF_getAppDir(){
  var p = decodeURIComponent(window.location.pathname);
  p = p.replace(/\//g, '\\');
  if (p.charAt(0) === '\\' && p.charAt(2) === ':') p = p.substring(1);
  return p.substring(0, p.lastIndexOf('\\'));
}
UF.ensureDir = function(path){ if (!UF.fso.FolderExists(path)) { UF.fso.CreateFolder(path); } };
function UF_writeText(path, text){ var ts = UF.fso.OpenTextFile(path, 2, true, -1); ts.Write(text); ts.Close(); }
function UF_appendText(path, text){ var ts = UF.fso.OpenTextFile(path, 8, true, -1); ts.Write(text); ts.Close(); }
function UF_readText(path){ if(!UF.fso.FileExists(path)) return ''; var ts=UF.fso.OpenTextFile(path,1,false,-1); var t=ts.ReadAll(); ts.Close(); return t; }
function UF_log(level, msg){
  var line = '[' + UF_iso() + '] [' + level + '] ' + msg;
  try { UF_appendText(UF.logFile, line + '\r\n'); } catch(e){}
  try {
    var box = UF_id('liveLog');
    if (box) { box.value += line + '\r\n'; if (box.value.length > 60000) box.value = box.value.substring(box.value.length - 45000); box.scrollTop = box.scrollHeight; }
  } catch(e2){}
}
function UF_crash(msg){ try { UF_appendText(UF.crashFile, '[' + UF_iso() + '] ' + msg + '\r\n'); } catch(e){} }
window.onerror = function(message, source, lineno, colno, error){ UF_crash('JS error line ' + lineno + ': ' + message); try { UF_log('ERROR', 'JS error line ' + lineno + ': ' + message); } catch(e){} return true; };

function UF_defaultSettings(){
  return { minLen:3, maxLen:4, workers:512, checksWorker:40, safeCap:25000, budgetMs:18, sleepMs:0, maxRows:1500,
    compactOutput:true, autoStart:true, charsLower:true, charsUpper:false, charsDigits:true, charsSpecials:true, smartGen:true,
    platforms:{ Discord:true, TikTok:true, Instagram:true, Telegram:false, Snapchat:false }, providerMode:'verified-cache',
    mentionMode:'none', roleId:'', mentionCooldown:300, autoLogVerified:true, allowWebhookSave:false, webhook:'' };
}
function UF_loadSettings(){
  UF.settings = UF_defaultSettings();
  try { if (UF.fso.FileExists(UF.settingsFile)) { var raw = UF_readText(UF.settingsFile); var obj = JSON.parse(raw); for (var k in obj) UF.settings[k] = obj[k]; } } catch(e){ UF_log('WARN', 'Settings load failed, defaults used: ' + UF_err(e)); }
}
function UF_saveSettings(){
  try {
    var s = UF_collectSettings();
    if (!s.allowWebhookSave) s.webhook = '';
    else s.webhook = UF_b64Encode(s.webhook);
    UF_writeText(UF.settingsFile, JSON.stringify(s, null, 2));
    UF_log('OK', 'Settings saved. Webhook saved=' + (s.allowWebhookSave ? 'obfuscated local file' : 'no/session only'));
  } catch(e) { UF_log('ERROR', 'Settings save failed: ' + UF_err(e)); }
}
function UF_collectSettings(){
  return { minLen:UF_num('minLen'), maxLen:UF_num('maxLen'), workers:UF_num('workers'), checksWorker:UF_num('checksWorker'), safeCap:UF_num('safeCap'), budgetMs:UF_num('budgetMs'), sleepMs:UF_num('sleepMs'), maxRows:UF_num('maxRows'),
    compactOutput:UF_id('compactOutput').checked, autoStart:UF_id('autoStart').checked, charsLower:UF_id('chars_lower').checked, charsUpper:UF_id('chars_upper').checked, charsDigits:UF_id('chars_digits').checked, charsSpecials:UF_id('chars_specials').checked, smartGen:UF_id('smartGen').checked,
    platforms:{ Discord:UF_id('platform_discord').checked, TikTok:UF_id('platform_tiktok').checked, Instagram:UF_id('platform_instagram').checked, Telegram:UF_id('platform_telegram').checked, Snapchat:UF_id('platform_snapchat').checked }, providerMode:UF_id('providerMode').value,
    webhook:UF_id('webhook').value, mentionMode:UF_id('mentionMode').value, roleId:UF_id('roleId').value, mentionCooldown:UF_num('mentionCooldown'), autoLogVerified:UF_id('autoLogVerified').checked, allowWebhookSave:UF_id('allowWebhookSave').checked };
}
function UF_applySettingsToUi(){
  var s = UF.settings;
  UF_set('minLen',s.minLen); UF_set('maxLen',s.maxLen); UF_set('workers',s.workers); UF_set('checksWorker',s.checksWorker); UF_set('safeCap',s.safeCap); UF_set('budgetMs',s.budgetMs); UF_set('sleepMs',s.sleepMs); UF_set('maxRows',s.maxRows);
  UF_id('compactOutput').checked = !!s.compactOutput; UF_id('autoStart').checked = !!s.autoStart; UF_id('chars_lower').checked = !!s.charsLower; UF_id('chars_upper').checked = !!s.charsUpper; UF_id('chars_digits').checked = !!s.charsDigits; UF_id('chars_specials').checked = !!s.charsSpecials; UF_id('smartGen').checked = !!s.smartGen;
  if (s.platforms) { UF_id('platform_discord').checked=!!s.platforms.Discord; UF_id('platform_tiktok').checked=!!s.platforms.TikTok; UF_id('platform_instagram').checked=!!s.platforms.Instagram; UF_id('platform_telegram').checked=!!s.platforms.Telegram; UF_id('platform_snapchat').checked=!!s.platforms.Snapchat; }
  UF_id('providerMode').value = s.providerMode || 'verified-cache'; UF_id('mentionMode').value = s.mentionMode || 'none'; UF_id('roleId').value = s.roleId || ''; UF_set('mentionCooldown', s.mentionCooldown || 300); UF_id('autoLogVerified').checked = !!s.autoLogVerified; UF_id('allowWebhookSave').checked = !!s.allowWebhookSave;
  if (s.allowWebhookSave && s.webhook) UF_id('webhook').value = UF_b64Decode(s.webhook); else UF_id('webhook').value = '';
}
function UF_num(id){ var v=parseInt(UF_id(id).value,10); if(isNaN(v)) v=0; return v; }
function UF_set(id,val){ UF_id(id).value = String(val); }
function UF_b64Encode(s){ try { return window.btoa(unescape(encodeURIComponent(s))); } catch(e){ return ''; } }
function UF_b64Decode(s){ try { return decodeURIComponent(escape(window.atob(s))); } catch(e){ return ''; } }

function UF_cachePath(name){ return UF.dataRoot + '\\' + name; }
function UF_key(platform, username){ return platform.toLowerCase() + ':' + username.toLowerCase(); }
function UF_loadTsv(name, target){
  var path = UF_cachePath(name); if (!UF.fso.FileExists(path)) return 0;
  var count=0;
  try {
    var text=UF_readText(path); var lines=text.split(/\r?\n/);
    for (var i=0;i<lines.length && i<350000;i++){
      var line=lines[i]; if(!line) continue;
      var p=line.split('\t'); if(p.length>=2){ target[UF_key(p[0],p[1])] = true; count++; }
    }
  } catch(e){ UF_log('WARN', 'Cache load failed ' + name + ': ' + UF_err(e)); }
  return count;
}
function UF_appendCache(name, platform, username, status, source){ try { UF_appendText(UF_cachePath(name), platform + '\t' + username + '\t' + status + '\t' + source + '\t' + UF_iso() + '\r\n'); } catch(e){} }
function UF_loadCaches(){
  var c1=UF_loadTsv('checked_usernames.tsv', UF.checkedCache);
  var c2=UF_loadTsv('invalid_usernames.tsv', UF.invalidCache);
  var c3=UF_loadTsv('taken_usernames.tsv', UF.takenCache);
  var c4=UF_loadTsv('verified_available_usernames.tsv', UF.validCache);
  var c5=UF_loadTsv('logged_valid_usernames.tsv', UF.loggedCache);
  UF_log('OK', 'Caches loaded: checked=' + c1 + ', invalid=' + c2 + ', taken=' + c3 + ', valid=' + c4 + ', logged=' + c5);
}
function UF_refreshCacheView(){
  try {
    var s = 'DATA ROOT: ' + UF.dataRoot + '\r\n\r\n';
    s += 'checked_usernames.tsv: ' + (UF.fso.FileExists(UF_cachePath('checked_usernames.tsv')) ? UF.fso.GetFile(UF_cachePath('checked_usernames.tsv')).Size + ' bytes' : 'not created') + '\r\n';
    s += 'invalid_usernames.tsv: ' + (UF.fso.FileExists(UF_cachePath('invalid_usernames.tsv')) ? UF.fso.GetFile(UF_cachePath('invalid_usernames.tsv')).Size + ' bytes' : 'not created') + '\r\n';
    s += 'taken_usernames.tsv: ' + (UF.fso.FileExists(UF_cachePath('taken_usernames.tsv')) ? UF.fso.GetFile(UF_cachePath('taken_usernames.tsv')).Size + ' bytes' : 'not created') + '\r\n';
    s += 'verified_available_usernames.tsv: ' + (UF.fso.FileExists(UF_cachePath('verified_available_usernames.tsv')) ? UF.fso.GetFile(UF_cachePath('verified_available_usernames.tsv')).Size + ' bytes' : 'not created') + '\r\n';
    s += 'logged_valid_usernames.tsv: ' + (UF.fso.FileExists(UF_cachePath('logged_valid_usernames.tsv')) ? UF.fso.GetFile(UF_cachePath('logged_valid_usernames.tsv')).Size + ' bytes' : 'not created') + '\r\n';
    UF_id('cacheView').value = s;
  } catch(e){}
}
function UF_bindContractText(){
  var t = 'TRUTH CONTRACT — Username Finder V23\r\n\r\n';
  t += '1) Local generation checks format only. It is not proof that a username is free.\r\n';
  t += '2) VALID_VERIFIED means the username came from a trusted source: verified CSV import, manual proof, or an official/allowed provider adapter.\r\n';
  t += '3) TAKEN_VERIFIED means the trusted source said the username is used or not available.\r\n';
  t += '4) INVALID_RULE means local platform syntax rules reject the username before any provider work.\r\n';
  t += '5) UNKNOWN_UNVERIFIED / READY_FOR_PROVIDER means format OK, but not proven. Discord never logs this as a hit.\r\n';
  t += '6) Discord webhook logs are sent only for VALID_VERIFIED rows, with duplicate protection and optional mention cooldown.\r\n';
  t += '7) Discord delivery uses a PowerShell broker to avoid HTA/MSXML permission errors and to support TLS/retries.\r\n';
  t += '8) No hidden scraping, no admin rights, no downloads, no SDK, no .NET GUI dependency.\r\n\r\n';
  t += 'Provider CSV statuses accepted: VALID_VERIFIED, VALID, AVAILABLE, FREE, TAKEN_VERIFIED, TAKEN, UNAVAILABLE, USED, INVALID_RULE, INVALID.\r\n';
  t += 'CSV columns: Platform,Username,Status,Source,LatencyMs,Score\r\n';
  try { UF_id('contractText').value = t; } catch(e){}
}

function UF_getPlatforms(){
  var arr=[];
  if(UF_id('platform_discord').checked) arr.push('Discord');
  if(UF_id('platform_tiktok').checked) arr.push('TikTok');
  if(UF_id('platform_instagram').checked) arr.push('Instagram');
  if(UF_id('platform_telegram').checked) arr.push('Telegram');
  if(UF_id('platform_snapchat').checked) arr.push('Snapchat');
  return arr;
}
function UF_allowedPlatformsForLen(platforms, minLen, maxLen){
  if(!UF_id('smartGen').checked) return platforms;
  var out=[];
  for(var i=0;i<platforms.length;i++){
    var r=UF.rules[platforms[i]];
    if(maxLen >= r.min && minLen <= r.max) out.push(platforms[i]);
  }
  return out;
}
function UF_charset(platform){
  var r=UF.rules[platform], s='';
  if(UF_id('chars_lower').checked && r.lower) s += 'abcdefghijklmnopqrstuvwxyz';
  if(UF_id('chars_upper').checked && r.upper) s += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  if(UF_id('chars_digits').checked && r.digits) s += '0123456789';
  if(UF_id('chars_specials').checked) s += r.specials;
  if(!s) s='abcdefghijklmnopqrstuvwxyz0123456789';
  var unique='', seen={};
  for(var i=0;i<s.length;i++){ var c=s.charAt(i); if(!seen[c]){ seen[c]=true; unique+=c; } }
  return unique;
}
function UF_randomInt(min,max){ return min + Math.floor(Math.random()*(max-min+1)); }
function UF_makeUsername(platform, minLen, maxLen){
  var r=UF.rules[platform];
  var lo=Math.max(minLen, r.min), hi=Math.min(maxLen, r.max);
  if(hi < lo) { lo=minLen; hi=maxLen; }
  var len=UF_randomInt(lo, hi);
  var chars=UF_charset(platform), letters='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  var u='', c='';
  for(var i=0;i<len;i++){
    if(i===0 && r.mustStartLetter) c = letters.charAt(UF_randomInt(0, letters.length-1));
    else c = chars.charAt(UF_randomInt(0, chars.length-1));
    u += c;
  }
  if(r.forceLower) u = u.toLowerCase();
  // repair obvious forbidden dot endings so generator wastes less time
  if(r.noEndDot && u.charAt(u.length-1)==='.') u = u.substring(0,u.length-1) + 'x';
  if(r.noStartDot && u.charAt(0)==='.') u = 'x' + u.substring(1);
  if(r.noDoubleDot) { while(u.indexOf('..') >= 0) u = u.replace('..','._'); }
  return u;
}
function UF_validateLocal(platform, u){
  var r=UF.rules[platform];
  if(!u || u.length===0) return 'empty';
  if(u.length < r.min || u.length > r.max) return 'length must be ' + r.min + '-' + r.max;
  if(r.mustStartLetter && !/^[A-Za-z]/.test(u)) return 'must start with a letter';
  if(r.noStartDot && u.charAt(0)==='.') return 'must not start with dot';
  if(r.noEndDot && u.charAt(u.length-1)==='.') return 'must not end with dot';
  if(r.noDoubleDot && u.indexOf('..') >= 0) return 'must not contain double dot';
  var allowed='abcdefghijklmnopqrstuvwxyz0123456789';
  if(r.upper) allowed += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  allowed += r.specials.replace(/[-\\\]^]/g,'\\$&');
  var re = new RegExp('^[' + allowed + ']+$');
  if(!re.test(u)) return 'contains chars not allowed by local platform rule';
  return '';
}
function UF_score(u){
  var score=50;
  if(u.length<=3) score+=18; else if(u.length===4) score+=11;
  if(/[0-9]/.test(u)) score+=8;
  if(/[._]/.test(u)) score+=6;
  if(/^[a-zA-Z]+$/.test(u)) score-=8;
  if(/(.)\1/.test(u)) score-=6;
  if(/^[aeiouAEIOU]+$/.test(u)) score-=5;
  if(score<1) score=1; if(score>99) score=99; return score;
}
function UF_classForStatus(status){
  if(status==='VALID_VERIFIED') return 'status_valid';
  if(status==='TAKEN_VERIFIED') return 'status_taken';
  if(status==='INVALID_RULE') return 'status_invalid';
  if(status==='READY_FOR_PROVIDER' || status==='UNKNOWN_UNVERIFIED') return 'status_ready';
  return '';
}
function UF_enqueueRow(platform, username, status, reason, source, latency, score){
  var row = { time:UF_time(), platform:platform, username:username, status:status, reason:reason, source:source, latency:latency, score:score };
  UF.exportRows.push(row);
  if(UF.exportRows.length > 50000) UF.exportRows.shift();
  var compact=UF_id('compactOutput').checked;
  if(!compact || status==='VALID_VERIFIED' || status==='TAKEN_VERIFIED' || status==='INVALID_RULE' || Math.random() < 0.035) UF.pendingRows.push(row);
  if(status==='VALID_VERIFIED') UF.pendingValidRows.push(row);
}
function UF_processCandidate(platform, username){
  var start=UF_nowMs();
  var key=UF_key(platform, username);
  UF.counters.generated++;
  if(UF.sessionSeen[key]) { UF.counters.duplicates++; return; }
  UF.sessionSeen[key]=true;
  if(UF.checkedCache[key]) { UF.counters.duplicates++; return; }
  var invalid=UF_validateLocal(platform, username);
  if(invalid) {
    if(!UF.invalidCache[key]) { UF.invalidCache[key]=true; UF_appendCache('invalid_usernames.tsv', platform, username, 'INVALID_RULE', invalid); }
    UF.counters.invalid++;
    UF_enqueueRow(platform, username, 'INVALID_RULE', invalid, 'Local rule gate', UF_nowMs()-start, 0);
    return;
  }
  if(UF.validCache[key]) {
    UF.counters.valid++;
    UF_enqueueRow(platform, username, 'VALID_VERIFIED', 'Trusted cache/provider says available', 'Verified cache', UF_nowMs()-start, 99);
    UF_maybeLogVerified(platform, username, 'Verified cache', UF_nowMs()-start, 99);
    return;
  }
  if(UF.takenCache[key]) {
    UF.counters.taken++;
    UF_enqueueRow(platform, username, 'TAKEN_VERIFIED', 'Trusted cache/provider says taken', 'Verified taken cache', UF_nowMs()-start, 0);
    return;
  }
  UF.counters.unknown++;
  var score=UF_score(username);
  var status = score >= 62 ? 'READY_FOR_PROVIDER' : 'UNKNOWN_UNVERIFIED';
  if(status==='READY_FOR_PROVIDER') UF.counters.predicted++;
  UF_enqueueRow(platform, username, status, 'Format OK; no trusted availability proof yet', 'Local rules + intelligence', UF_nowMs()-start, score);
}
function UF_startEngine(){
  if(UF.running) { UF_log('INFO', 'Engine already running.'); return; }
  UF_saveSettings();
  UF.running = true;
  UF.noPlatformWarned = false;
  UF.lastGenerated = UF.counters.generated;
  UF.lastRateMs = UF_nowMs();
  UF_id('btnStartTop').disabled = true;
  UF_log('OK', 'Instant turbo engine started: workers=' + UF_num('workers') + ', checks/worker=' + UF_num('checksWorker') + ', safe cap=' + UF_num('safeCap') + ', budget=' + UF_num('budgetMs') + 'ms.');
  UF_id('statusText').innerText = 'Engine running — local candidates are generated; only VALID_VERIFIED can log to Discord.';
  UF_tickEngine();
}
function UF_stopEngine(){
  UF.running = false;
  if(UF.tickTimer) { window.clearTimeout(UF.tickTimer); UF.tickTimer=null; }
  try{ UF_id('btnStartTop').disabled = false; }catch(e){}
  UF_log('OK', 'Engine stopped.');
  UF_id('statusText').innerText = 'Stopped.';
}
function UF_tickEngine(){
  if(!UF.running) return;
  try {
    var platforms=UF_getPlatforms();
    var minLen=UF_num('minLen'), maxLen=UF_num('maxLen');
    if(maxLen < minLen) { var tmp=minLen; minLen=maxLen; maxLen=tmp; }
    platforms=UF_allowedPlatformsForLen(platforms, minLen, maxLen);
    if(platforms.length<1){
      if(!UF.noPlatformWarned) { UF_log('WARN', 'No selected platform has a possible length range. Change length or platforms.'); UF.noPlatformWarned=true; }
      UF.tickTimer = window.setTimeout(UF_tickEngine, 500); return;
    }
    UF.noPlatformWarned=false;
    var workers=Math.max(1, Math.min(2048, UF_num('workers')));
    var checks=Math.max(1, Math.min(1000, UF_num('checksWorker')));
    var cap=Math.max(100, Math.min(100000, UF_num('safeCap')));
    var target=Math.min(cap, workers*checks);
    var budget=Math.max(4, Math.min(80, UF_num('budgetMs')));
    var endTime=UF_nowMs()+budget;
    var processed=0;
    while(processed < target && UF_nowMs() < endTime){
      var p=platforms[UF_randomInt(0,platforms.length-1)];
      var u=UF_makeUsername(p, minLen, maxLen);
      UF_processCandidate(p,u);
      processed++;
    }
    if(processed===0){
      var pp=platforms[UF_randomInt(0,platforms.length-1)];
      UF_processCandidate(pp, UF_makeUsername(pp, minLen, maxLen));
    }
  } catch(e) { UF_log('ERROR', 'Engine tick failed: ' + UF_err(e)); UF_crash('Engine tick failed: ' + UF_err(e)); }
  UF.tickTimer = window.setTimeout(UF_tickEngine, Math.max(0, Math.min(500, UF_num('sleepMs'))));
}
function UF_updateCards(){
  try {
    var now=UF_nowMs();
    var diff=(now-UF.lastRateMs)/1000;
    if(diff>=0.5){ UF.counters.rate=Math.floor((UF.counters.generated-UF.lastGenerated)/diff); UF.lastGenerated=UF.counters.generated; UF.lastRateMs=now; }
    UF_id('cardGenerated').innerText=UF_fmt(UF.counters.generated);
    UF_id('cardUnknown').innerText=UF_fmt(UF.counters.unknown);
    UF_id('cardPredicted').innerText=UF_fmt(UF.counters.predicted);
    UF_id('cardValid').innerText=UF_fmt(UF.counters.valid);
    UF_id('cardTaken').innerText=UF_fmt(UF.counters.taken);
    UF_id('cardRate').innerText=UF_fmt(UF.counters.rate);
    UF_id('cardWorkers').innerText=UF_fmt(UF_num('workers'));
    UF_id('cardDuplicates').innerText=UF_fmt(UF.counters.duplicates);
    UF_id('cardInvalid').innerText=UF_fmt(UF.counters.invalid);
    UF_id('cardLogged').innerText=UF_fmt(UF.counters.logged);
    try { UF_id('cardWebhook').innerText = UF_getWebhookStatusShort(); } catch(x){}
  } catch(e){}
}
function UF_flushUi(){
  try {
    var tbody = UF_id('resultsTable').tBodies[0];
    var maxRows=Math.max(50, Math.min(10000, UF_num('maxRows')));
    var addLimit=UF_id('compactOutput').checked ? 90 : 300;
    var added=0;
    while(UF.pendingRows.length>0 && added<addLimit){
      var r=UF.pendingRows.shift();
      var tr=tbody.insertRow(-1); tr.className=UF_classForStatus(r.status);
      UF_addCell(tr,r.time); UF_addCell(tr,r.platform); UF_addCell(tr,r.username); UF_addCell(tr,r.status); UF_addCell(tr,r.reason); UF_addCell(tr,r.source); UF_addCell(tr,String(r.latency)); UF_addCell(tr,String(r.score));
      added++;
    }
    while(tbody.rows.length > maxRows) tbody.deleteRow(0);
    var vbody = UF_id('validTable').tBodies[0];
    while(UF.pendingValidRows.length>0){
      var vr=UF.pendingValidRows.shift(); var vtr=vbody.insertRow(-1);
      UF_addCell(vtr,vr.time); UF_addCell(vtr,vr.platform); UF_addCell(vtr,vr.username); UF_addCell(vtr,vr.source); UF_addCell(vtr,UF.loggedCache[UF_key(vr.platform,vr.username)] ? 'yes' : 'pending/no webhook');
    }
    while(vbody.rows.length > 2000) vbody.deleteRow(0);
  } catch(e) { UF_crash('Flush UI failed: ' + UF_err(e)); }
}
function UF_addCell(tr, text){ var td=tr.insertCell(-1); td.innerText=text; td.title=text; }
function UF_showTab(name){
  var names=['results','valid','taken','log','contract','diagnostics'];
  for(var i=0;i<names.length;i++){ var b=UF_id('tab_'+names[i]); if(b) b.className='tabBody'; }
  UF_id('tab_'+name).className='tabBody visible';
  var tabs=document.getElementsByClassName ? document.getElementsByClassName('tab') : [];
  for(var j=0;j<tabs.length;j++) tabs[j].className='tab';
  try { window.event.srcElement.className='tab active'; } catch(e){}
  if(name==='taken') UF_refreshCacheView();
}
function UF_preset(name){
  if(name==='balanced'){ UF_set('workers',512); UF_set('checksWorker',40); UF_set('safeCap',25000); UF_set('budgetMs',18); UF_set('sleepMs',0); }
  if(name==='turbo'){ UF_set('workers',1024); UF_set('checksWorker',80); UF_set('safeCap',75000); UF_set('budgetMs',24); UF_set('sleepMs',0); }
  if(name==='ultra'){ UF_set('workers',2048); UF_set('checksWorker',100); UF_set('safeCap',100000); UF_set('budgetMs',32); UF_set('sleepMs',0); }
  UF_saveSettings(); UF_log('OK', 'Preset applied: ' + name);
}
function UF_clearResults(){
  try { UF_id('resultsTable').tBodies[0].innerHTML=''; UF_id('validTable').tBodies[0].innerHTML=''; UF_id('liveLog').value=''; UF.pendingRows=[]; UF.pendingValidRows=[]; UF.exportRows=[]; } catch(e){}
}
function UF_openLogs(){
  try { UF.shell.Run('explorer.exe "' + UF.installRoot + '"', 1, false); } catch(e){ UF_log('WARN','Cannot open logs folder: '+UF_err(e)); }
}
function UF_clearWebhook(){ UF_id('webhook').value=''; UF_saveSettings(); }

function UF_importVerifyCsv(){
  try {
    var defaultPath = UF_cachePath('verify_import.csv');
    var path = prompt('CSV path eingeben. Leer = ' + defaultPath + '\nColumns: Platform,Username,Status,Source,LatencyMs,Score', defaultPath);
    if(path===null) return; if(path==='') path=defaultPath;
    if(!UF.fso.FileExists(path)){ alert('Datei nicht gefunden:\n' + path); return; }
    var text=UF_readText(path); var lines=text.split(/\r?\n/); var valid=0, taken=0, invalid=0, skipped=0;
    for(var i=0;i<lines.length;i++){
      var line=lines[i]; if(!line || /^\s*platform\s*,/i.test(line)) continue;
      var cols=UF_parseCsvLine(line); if(cols.length<3){ skipped++; continue; }
      var platform=UF_cleanPlatform(cols[0]); var username=UF_trim(cols[1]); var status=UF_trim(cols[2]).toUpperCase(); var source=cols.length>3 && cols[3] ? UF_trim(cols[3]) : 'CSV import'; var latency=cols.length>4 ? parseInt(cols[4],10) : 0; if(isNaN(latency)) latency=0; var score=cols.length>5 ? parseInt(cols[5],10) : 99; if(isNaN(score)) score=99;
      if(!UF.rules[platform] || !username){ skipped++; continue; }
      var key=UF_key(platform, username);
      if(status==='VALID_VERIFIED' || status==='VALID' || status==='AVAILABLE' || status==='FREE'){
        if(!UF.validCache[key]) { UF.validCache[key]=true; UF_appendCache('verified_available_usernames.tsv', platform, username, 'VALID_VERIFIED', source); }
        valid++; UF_enqueueRow(platform, username, 'VALID_VERIFIED', 'Trusted CSV import says available', source, latency, score); UF.pendingValidRows.push({time:UF_time(), platform:platform, username:username, source:source});
        if(UF_id('autoLogVerified').checked) UF_maybeLogVerified(platform, username, source, latency, score);
      } else if(status==='TAKEN_VERIFIED' || status==='TAKEN' || status==='UNAVAILABLE' || status==='USED'){
        if(!UF.takenCache[key]) { UF.takenCache[key]=true; UF_appendCache('taken_usernames.tsv', platform, username, 'TAKEN_VERIFIED', source); }
        taken++; UF_enqueueRow(platform, username, 'TAKEN_VERIFIED', 'Trusted CSV import says taken', source, latency, 0);
      } else if(status==='INVALID_RULE' || status==='INVALID'){
        if(!UF.invalidCache[key]) { UF.invalidCache[key]=true; UF_appendCache('invalid_usernames.tsv', platform, username, 'INVALID_RULE', source); }
        invalid++; UF_enqueueRow(platform, username, 'INVALID_RULE', 'Trusted CSV import says invalid', source, latency, 0);
      } else skipped++;
    }
    UF.counters.valid += valid; UF.counters.taken += taken; UF.counters.invalid += invalid;
    UF_log('OK', 'Import completed: valid=' + valid + ', taken=' + taken + ', invalid=' + invalid + ', skipped=' + skipped);
    UF_refreshCacheView(); UF_updateCards();
  } catch(e){ UF_log('ERROR','Import failed: '+UF_err(e)); UF_crash('Import failed: '+UF_err(e)); }
}
function UF_cleanPlatform(s){ s=UF_trim(s).toLowerCase(); if(s==='discord')return'Discord'; if(s==='tiktok'||s==='tik tok')return'TikTok'; if(s==='instagram'||s==='insta')return'Instagram'; if(s==='telegram')return'Telegram'; if(s==='snapchat'||s==='snap')return'Snapchat'; return UF_trim(s); }
function UF_trim(s){ return String(s).replace(/^\s+|\s+$/g,''); }
function UF_parseCsvLine(line){
  var out=[], cur='', q=false;
  for(var i=0;i<line.length;i++){
    var ch=line.charAt(i);
    if(ch==='"') { if(q && line.charAt(i+1)==='"') { cur+='"'; i++; } else q=!q; }
    else if(ch===',' && !q){ out.push(cur); cur=''; }
    else cur+=ch;
  }
  out.push(cur); return out;
}
function UF_writeImportTemplate(){
  var path=UF_cachePath('verify_import.csv');
  var text='Platform,Username,Status,Source,LatencyMs,Score\r\nDiscord,snoxy_test,VALID_VERIFIED,Manual proof,120,99\r\nTikTok,abc,TAKEN_VERIFIED,Official provider,88,0\r\nInstagram,x_7,INVALID_RULE,Local rule,0,0\r\n';
  UF_writeText(path,text); UF_log('OK','Import template created: '+path); UF.shell.Run('notepad.exe "'+path+'"',1,false);
}
function UF_maybeLogVerified(platform, username, source, latency, score){
  try {
    var key=UF_key(platform, username);
    if(UF.loggedCache[key]) return;
    var webhook=UF_trim(UF_id('webhook').value);
    if(!UF_isValidDiscordWebhook(webhook)){ UF_log('WARN','VALID_VERIFIED found but no valid Discord webhook set: '+platform+'/'+username); return; }
    var queued = UF_sendDiscordVerified(platform, username, source, latency, score);
    if(queued){
      UF.loggedCache[key]=true;
      UF_appendCache('logged_valid_usernames.tsv', platform, username, 'LOG_QUEUED', source);
      UF.counters.logged++;
    }
  } catch(e){ UF_log('ERROR','Discord log failed: '+UF_err(e)); UF_crash('Discord log failed: '+UF_err(e)); }
}
function UF_isValidDiscordWebhook(webhook){
  return /^https:\/\/(discord(?:app)?\.com|canary\.discord(?:app)?\.com|ptb\.discord(?:app)?\.com)\/api\/(?:v\d+\/)?webhooks\/\d+\/[A-Za-z0-9_\-.]+(?:\?.*)?$/i.test(UF_trim(webhook));
}
function UF_jsonEscape(s){ return String(s).replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r/g,'\\r').replace(/\n/g,'\\n'); }
function UF_field(name, value, inline){ return '{"name":"'+UF_jsonEscape(name)+'","value":"'+UF_jsonEscape(value)+'","inline":'+(inline?'true':'false')+'}'; }
function UF_safeFilePart(s){ return String(s).replace(/[^A-Za-z0-9_.-]/g,'_').substring(0,80); }
function UF_quoteArg(s){ return '"' + String(s).replace(/"/g,'""') + '"'; }
function UF_buildDiscordVerifiedPayload(platform, username, source, latency, score, modeLabel){
  var mentionMode=UF_id('mentionMode').value, roleId=UF_trim(UF_id('roleId').value), content='', allowed='{"parse":[]}';
  var cooldown=Math.max(0, UF_num('mentionCooldown'))*1000, now=UF_nowMs();
  if(modeLabel==='PREVIEW') { mentionMode='none'; }
  if(mentionMode==='@everyone'){
    if(now-UF.lastMentionMs>=cooldown){ content='@everyone '; allowed='{"parse":["everyone"]}'; UF.lastMentionMs=now; } else { content=''; }
  } else if(mentionMode==='@here'){
    if(now-UF.lastMentionMs>=cooldown){ content='@here '; allowed='{"parse":["everyone"]}'; UF.lastMentionMs=now; } else { content=''; }
  } else if(mentionMode==='role' && /^\d+$/.test(roleId)){
    if(now-UF.lastMentionMs>=cooldown){ content='<@&'+roleId+'> '; allowed='{"parse":[],"roles":["'+roleId+'"]}'; UF.lastMentionMs=now; } else { content=''; }
  }
  var verifyId = platform.toUpperCase().replace(/[^A-Z0-9]/g,'') + '-' + (new Date().getTime()) + '-' + Math.floor(Math.random()*99999);
  content += '✅ **VALID VERIFIED username found**';
  var color=5763719;
  var fields=[];
  fields.push(UF_field('🧩 Platform', platform, true));
  fields.push(UF_field('👤 Username', '`'+username+'`', true));
  fields.push(UF_field('✅ Truth Status', 'VALID_VERIFIED', true));
  fields.push(UF_field('🆔 Verification ID', verifyId, true));
  fields.push(UF_field('🔐 Trusted Source', source || 'Verified cache/import/provider', true));
  fields.push(UF_field('⚡ Provider Latency', String(latency || 0)+' ms', true));
  fields.push(UF_field('🧠 Confidence Score', String(score || 99)+'/99', true));
  fields.push(UF_field('📦 Engine Snapshot', 'Generated '+UF_fmt(UF.counters.generated)+' • Duplicates '+UF_fmt(UF.counters.duplicates)+' • Workers '+UF_fmt(UF_num('workers')), false));
  fields.push(UF_field('🛡️ Safety Gate', 'Only VALID_VERIFIED imports/provider results are logged. Local candidates are never logged as free.', false));
  fields.push(UF_field('🕒 Timestamp', UF_iso(), true));
  fields.push(UF_field('🧰 Delivery', 'HTA UI → PowerShell TLS Broker → Discord Webhook', true));
  var payload = '{"content":"'+UF_jsonEscape(content)+'","username":"Username Finder • Snoxy.dev","allowed_mentions":'+allowed+',"embeds":[{"title":"✅ Username Finder • VALID VERIFIED","description":"Ultra-clean verified availability log. No fake local predictions.","color":'+color+',"fields":['+fields.join(',')+'],"footer":{"text":"Username Finder V23 • Snoxy.dev • Discord Broker • '+UF_jsonEscape(verifyId)+'"},"timestamp":"'+UF_iso()+'"}]}';
  return payload;
}
function UF_sendDiscordVerified(platform, username, source, latency, score){
  var payload = UF_buildDiscordVerifiedPayload(platform, username, source, latency, score, 'LIVE');
  return UF_queueDiscordPayload(payload, 'verified_'+UF_safeFilePart(platform)+'_'+UF_safeFilePart(username));
}
function UF_testWebhook(){
  try {
    var webhook=UF_trim(UF_id('webhook').value);
    if(!UF_isValidDiscordWebhook(webhook)){ UF_diagnoseWebhook(); alert('Kein gültiger Discord Webhook gesetzt. Bitte vollständige URL kopieren.'); return; }
    var fields=[];
    fields.push(UF_field('🧪 Test Type','Broker connectivity test — no username hit',true));
    fields.push(UF_field('🧰 Runtime','HTA UI → PowerShell TLS Broker → Discord',true));
    fields.push(UF_field('🔐 Safety','Real username logs require VALID_VERIFIED',false));
    fields.push(UF_field('📁 Result Log',UF.webhookResultFile,false));
    fields.push(UF_field('🕒 Time',UF_iso(),true));
    var payload='{"content":"🧪 **Username Finder V23 webhook broker test** — no fake availability.","allowed_mentions":{"parse":[]},"embeds":[{"title":"🧪 Snoxy.dev Webhook Broker Test","description":"If you see this, the webhook route works. Real username alerts are verified-only.","color":3447003,"fields":['+fields.join(',')+'],"footer":{"text":"Username Finder V23 • Discord Broker Test"},"timestamp":"'+UF_iso()+'"}]}';
    if(UF_queueDiscordPayload(payload, 'webhook_test')) UF_log('OK','Webhook test queued through broker. Result will appear in webhook_results.log.');
  } catch(e){ UF_log('ERROR','Webhook test failed: '+UF_err(e)); }
}
function UF_queueDiscordPayload(payload, label){
  try {
    var webhook=UF_trim(UF_id('webhook').value);
    if(!UF_isValidDiscordWebhook(webhook)){ UF_log('ERROR','Discord webhook is missing or invalid.'); UF_diagnoseWebhook(); return false; }
    if(!UF.webhookOutbox || !UF.fso.FolderExists(UF.webhookOutbox)) UF.ensureDir(UF.webhookOutbox);
    if(!UF.webhookBroker || !UF.fso.FileExists(UF.webhookBroker)){
      UF_log('ERROR','Discord broker missing: '+UF.webhookBroker);
      UF_diagnoseWebhook();
      alert('Discord Broker fehlt:\n' + UF.webhookBroker + '\nBitte V19 neu installieren.');
      return false;
    }
    var ts = String((new Date()).getTime()) + '_' + Math.floor(Math.random()*1000000);
    var payloadPath = UF.webhookOutbox + '\\' + UF_safeFilePart(label) + '_' + ts + '.json';
    var webhookPath = UF.webhookOutbox + '\\webhook_' + ts + '.txt';
    UF_writeText(payloadPath, payload);
    UF_writeText(webhookPath, webhook);
    var ps = UF.shell.ExpandEnvironmentStrings('%SystemRoot%') + '\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
    if(!UF.fso.FileExists(ps)){ UF_log('ERROR','PowerShell 5.1 not found at '+ps); UF_diagnoseWebhook(); return false; }
    var cmd = UF_quoteArg(ps) + ' -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ' + UF_quoteArg(UF.webhookBroker) + ' -WebhookFile ' + UF_quoteArg(webhookPath) + ' -PayloadFile ' + UF_quoteArg(payloadPath) + ' -ResultLog ' + UF_quoteArg(UF.webhookResultFile) + ' -Label ' + UF_quoteArg(label) + ' -DeleteWebhookFile';
    UF.shell.Run(cmd, 0, false);
    UF_log('OK','Discord payload queued through broker: '+label+' -> '+payloadPath);
    return true;
  } catch(e){ UF_log('ERROR','Queue Discord payload failed: '+UF_err(e)); UF_crash('Queue Discord payload failed: '+UF_err(e)); return false; }
}
function UF_pollWebhookResults(){
  try {
    if(!UF.fso.FileExists(UF.webhookResultFile)) return;
    var text=UF_readText(UF.webhookResultFile);
    if(text===UF.webhookLastText) return;
    var addition=text.substring(UF.webhookLastText.length);
    UF.webhookLastText=text;
    var lines=addition.split(/\r?\n/);
    for(var i=0;i<lines.length;i++){
      if(lines[i]){
        if(lines[i].indexOf('[OK]')>=0) UF_log('DISCORD', lines[i]);
        else if(lines[i].indexOf('[WARN]')>=0) UF_log('DISCORD-WARN', lines[i]);
        else if(lines[i].indexOf('[ERROR]')>=0) UF_log('DISCORD-ERROR', lines[i]);
      }
    }
  } catch(e){}
}
function UF_openWebhookResults(){
  try {
    if(!UF.fso.FileExists(UF.webhookResultFile)) UF_writeText(UF.webhookResultFile, '['+UF_iso()+'] [INFO] webhook_results.log created.\r\n');
    UF.shell.Run('notepad.exe '+UF_quoteArg(UF.webhookResultFile),1,false);
  } catch(e){ UF_log('WARN','Cannot open webhook log: '+UF_err(e)); }
}

function UF_getWebhookStatusShort(){
  try {
    var webhook = UF_trim(UF_id('webhook').value);
    if(!UF.webhookBroker || !UF.fso.FileExists(UF.webhookBroker)) return 'broker missing';
    if(!UF_isValidDiscordWebhook(webhook)) return 'no/invalid url';
    var ps = UF.shell.ExpandEnvironmentStrings('%SystemRoot%') + '\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
    if(!UF.fso.FileExists(ps)) return 'no powershell';
    return 'ready';
  } catch(e){ return 'check failed'; }
}
function UF_diagnoseWebhook(){
  try {
    var lines=[];
    var webhook = UF_trim(UF_id('webhook').value);
    var ps = UF.shell.ExpandEnvironmentStrings('%SystemRoot%') + '\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
    lines.push('DISCORD WEBHOOK DIAGNOSTICS — Username Finder ' + UF.version);
    lines.push('Time: ' + UF_iso());
    lines.push('Webhook field: ' + (webhook ? 'present ('+webhook.length+' chars)' : 'EMPTY'));
    lines.push('Webhook syntax: ' + (UF_isValidDiscordWebhook(webhook) ? 'OK' : 'INVALID / incomplete URL'));
    lines.push('Broker path: ' + UF.webhookBroker);
    lines.push('Broker exists: ' + (UF.fso.FileExists(UF.webhookBroker) ? 'YES' : 'NO'));
    lines.push('Outbox: ' + UF.webhookOutbox);
    lines.push('Outbox exists: ' + (UF.fso.FolderExists(UF.webhookOutbox) ? 'YES' : 'NO'));
    lines.push('PowerShell 5.1: ' + ps + ' -> ' + (UF.fso.FileExists(ps) ? 'YES' : 'NO'));
    lines.push('Result log: ' + UF.webhookResultFile);
    lines.push('Mention mode: ' + UF_id('mentionMode').value);
    lines.push('Cooldown sec: ' + UF_num('mentionCooldown'));
    lines.push('Save webhook locally: ' + (UF_id('allowWebhookSave').checked ? 'enabled' : 'disabled/session only'));
    lines.push('');
    lines.push('Common Discord errors:');
    lines.push('401/404 = wrong/deleted webhook URL or token incomplete.');
    lines.push('403 = webhook exists but Discord/server/channel denied the action.');
    lines.push('429 = rate limit; broker retries automatically.');
    lines.push('400 = malformed payload or Discord content/embed limit exceeded.');
    var text=lines.join('\r\n');
    try { UF_id('diagnosticsText').value = text; UF_showTab('diagnostics'); } catch(e){}
    UF_log('DIAG', 'Webhook diagnostics: ' + text.replace(/\r?\n/g,' | '));
    alert(text);
  } catch(e){ UF_log('ERROR','Webhook diagnostics failed: '+UF_err(e)); }
}
function UF_runSelfDiagnostics(){
  try {
    UF_diagnoseWebhook();
    UF_refreshCacheView();
    UF_log('DIAG','Runtime OK. appDir='+UF.appDir+' dataRoot='+UF.dataRoot+' broker='+UF.webhookBroker);
  } catch(e){ UF_log('ERROR','Self diagnostics failed: '+UF_err(e)); }
}
function UF_openDataFolder(){
  try { UF.shell.Run('explorer.exe '+UF_quoteArg(UF.dataRoot),1,false); } catch(e){ UF_log('WARN','Cannot open data folder: '+UF_err(e)); }
}
function UF_previewDiscordEmbed(){
  try {
    var sample = UF_buildDiscordVerifiedPayload('Discord','snoxy_test','Preview only — not logged',123,99,'PREVIEW');
    UF_id('diagnosticsText').value = 'DISCORD EMBED PAYLOAD PREVIEW — not sent\r\n\r\n' + sample;
    UF_showTab('diagnostics');
  } catch(e){ UF_log('ERROR','Preview failed: '+UF_err(e)); }
}

function UF_exportCsv(){
  try {
    var path=UF.dataRoot+'\\export_'+(new Date().getTime())+'.csv';
    var text='Time,Platform,Username,Status,Reason,Source,LatencyMs,Score\r\n';
    for(var i=0;i<UF.exportRows.length;i++){
      var r=UF.exportRows[i];
      text += UF_csv(r.time)+','+UF_csv(r.platform)+','+UF_csv(r.username)+','+UF_csv(r.status)+','+UF_csv(r.reason)+','+UF_csv(r.source)+','+UF_csv(r.latency)+','+UF_csv(r.score)+'\r\n';
    }
    UF_writeText(path,text); UF_log('OK','Export written: '+path); UF.shell.Run('explorer.exe /select,"'+path+'"',1,false);
  } catch(e){ UF_log('ERROR','Export failed: '+UF_err(e)); }
}
function UF_csv(v){ v=String(v); if(/[",\r\n]/.test(v)) return '"'+v.replace(/"/g,'""')+'"'; return v; }


/* =====================================================================================
   V23 COMPLIANT VERIFY SAFE OVERRIDES
   Purpose: no fake availability. The visible Results table is now true-status only:
   VALID_VERIFIED, TAKEN_VERIFIED, INVALID_RULE. Local candidates are only queued to a
   trusted provider adapter or ignored when no provider exists.
   ===================================================================================== */
UF.providerGateway = '';
UF.providerAdapter = '';
UF.providerInbox = '';
UF.providerOut = '';
UF.providerLogFile = '';
UF.providerQueue = [];
UF.providerPendingFiles = {};
UF.providerSeq = 0;
UF.providerPollTimer = null;
UF.providerMissingWarned = false;
UF.providerBatchSize = 500;
UF.providerMaxPending = 12;
UF.providerConfigured = false;
UF.providerLastStatus = 'checking';

var UF_initRuntime_V19 = UF_initRuntime;
UF_initRuntime = function(){
  UF_initRuntime_V19();
  UF.settingsFile = UF.dataRoot + '\\settings_v22.json';
  UF.providerGateway = UF.appDir + '\\tools\\ProviderGateway.ps1';
  UF.providerAdapter = UF.appDir + '\\..\\providers\\OfficialProvider.ps1';
  UF.providerInbox = UF.dataRoot + '\\provider_inbox';
  UF.providerOut = UF.dataRoot + '\\provider_results';
  UF.providerLogFile = UF.installRoot + '\\provider_gateway.log';
  UF.ensureDir(UF.providerInbox);
  UF.ensureDir(UF.providerOut);
  try { if(!UF.fso.FileExists(UF.providerLogFile)) UF_writeText(UF.providerLogFile, '['+UF_iso()+'] [INFO] Provider gateway log created by V23.\r\n'); } catch(_e){}
};

var UF_defaultSettings_V19 = UF_defaultSettings;
UF_defaultSettings = function(){
  var s = UF_defaultSettings_V19();
  s.providerMode = 'official-provider';
  s.autoStart = false;
  s.workers = 512; s.checksWorker = 40; s.safeCap = 25000; s.budgetMs = 18; s.sleepMs = 0; s.maxRows = 2500;
  return s;
};

var UF_bindContractText_V19 = UF_bindContractText;
UF_bindContractText = function(){
  var t = 'TRUTH CONTRACT — Username Finder V23 COMPLIANT VERIFY SAFE\r\n\r\n';
  t += 'CORE RULE: The app must not claim a username is free/taken unless a trusted source verifies it.\r\n\r\n';
  t += '1) Local generation is only a candidate pipeline. It checks syntax and cache duplicates only.\r\n';
  t += '2) Results table is true-status only: VALID_VERIFIED, TAKEN_VERIFIED, INVALID_RULE.\r\n';
  t += '3) Discord logs are sent only for VALID_VERIFIED. No UNKNOWN/PREDICTED/LOCAL-only rows are logged.\r\n';
  t += '4) Official Provider Adapter mode requires providers\\OfficialProvider.ps1. Without it the engine stops honestly.\r\n';
  t += '5) Import CSV Provider mode accepts trusted offline results and updates VALID/TAKEN/INVALID caches.\r\n';
  t += '6) Verified Cache Only mode replays/stores existing trusted caches but cannot discover new availability.\r\n';
  t += '7) No hidden scraping, no bypassing rate limits, no fake hit generation, no account enumeration logic.\r\n';
  t += '8) High speed is used for local candidate creation and provider batching; real network speed depends on your official provider limits.\r\n\r\n';
  t += 'Provider adapter input: batch TSV with Platform and Username.\r\n';
  t += 'Provider output columns: Platform,Username,Status,Source,LatencyMs,Score,Reason.\r\n';
  t += 'Accepted statuses: VALID_VERIFIED, TAKEN_VERIFIED, INVALID_RULE, UNKNOWN_UNVERIFIED.\r\n';
  try { UF_id('contractText').value = t; } catch(e){}
};

function UF_providerStatusShort(){
  try {
    if(!UF.providerGateway || !UF.fso.FileExists(UF.providerGateway)) return 'gateway missing';
    if(UF_id('providerMode').value !== 'official-provider') return UF_id('providerMode').value;
    if(!UF.fso.FileExists(UF.providerAdapter)) return 'adapter missing';
    return 'ready';
  } catch(e){ return 'check failed'; }
}

function UF_diagnoseProvider(){
  try {
    var ps = UF.shell.ExpandEnvironmentStrings('%SystemRoot%') + '\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
    var lines=[];
    lines.push('PROVIDER DIAGNOSTICS — Username Finder ' + UF.version);
    lines.push('Time: ' + UF_iso());
    lines.push('Mode: ' + UF_id('providerMode').value);
    lines.push('Gateway: ' + UF.providerGateway);
    lines.push('Gateway exists: ' + (UF.fso.FileExists(UF.providerGateway) ? 'YES' : 'NO'));
    lines.push('Official adapter: ' + UF.providerAdapter);
    lines.push('Official adapter exists: ' + (UF.fso.FileExists(UF.providerAdapter) ? 'YES' : 'NO'));
    lines.push('PowerShell: ' + ps + ' -> ' + (UF.fso.FileExists(ps) ? 'YES' : 'NO'));
    lines.push('Inbox: ' + UF.providerInbox);
    lines.push('Results: ' + UF.providerOut);
    lines.push('Gateway log: ' + UF.providerLogFile);
    lines.push('Queued candidates in memory: ' + UF.providerQueue.length);
    lines.push('Pending batch files: ' + UF_objCount(UF.providerPendingFiles));
    lines.push('');
    lines.push('To perform real VALID/TAKEN checks, install an allowed provider as:');
    lines.push(UF.providerAdapter);
    lines.push('The provider must return only statuses it can prove from an allowed source.');
    var text=lines.join('\r\n');
    try { UF_id('providerText').value = text; UF_showTab('provider'); } catch(e2){}
    UF_log('DIAG','Provider diagnostics: ' + text.replace(/\r?\n/g,' | '));
  } catch(e){ UF_log('ERROR','Provider diagnostics failed: '+UF_err(e)); }
}
function UF_openProvidersFolder(){
  try { UF.shell.Run('explorer.exe '+UF_quoteArg(UF.appDir + '\\..\\providers'),1,false); } catch(e){ UF_log('WARN','Cannot open providers folder: '+UF_err(e)); }
}
function UF_openProviderLog(){
  try { UF.shell.Run('notepad.exe '+UF_quoteArg(UF.providerLogFile),1,false); } catch(e){ UF_log('WARN','Cannot open provider log: '+UF_err(e)); }
}
function UF_objCount(o){ var n=0; try { for(var k in o) if(o.hasOwnProperty(k)) n++; } catch(e){} return n; }
function UF_csvEscape(v){ v=String(v); if(/[",\r\n]/.test(v)) return '"'+v.replace(/"/g,'""')+'"'; return v; }

// More strict true-only result display: only real statuses enter the Results grid.
var UF_enqueueRow_V19 = UF_enqueueRow;
UF_enqueueRow = function(platform, username, status, reason, source, latency, score){
  if(status==='VALID_VERIFIED' || status==='TAKEN_VERIFIED' || status==='INVALID_RULE'){
    UF_enqueueRow_V19(platform, username, status, reason, source, latency, score);
  } else {
    // Keep export for audit, but do not display local guesses in Results.
    var row = { time:UF_time(), platform:platform, username:username, status:status, reason:reason, source:source, latency:latency, score:score };
    UF.exportRows.push(row); if(UF.exportRows.length > 50000) UF.exportRows.shift();
  }
};

var UF_classForStatus_V19 = UF_classForStatus;
UF_classForStatus = function(status){
  if(status==='VALID_VERIFIED') return 'status_valid';
  if(status==='TAKEN_VERIFIED') return 'status_taken';
  if(status==='INVALID_RULE') return 'status_invalid';
  if(status==='QUEUED_FOR_PROVIDER' || status==='NO_PROVIDER_CONFIGURED') return 'status_provider';
  return UF_classForStatus_V19(status);
};

UF_processCandidate = function(platform, username){
  var start=UF_nowMs();
  var key=UF_key(platform, username);
  UF.counters.generated++;
  if(UF.sessionSeen[key]) { UF.counters.duplicates++; return; }
  UF.sessionSeen[key]=true;
  if(UF.checkedCache[key]) { UF.counters.duplicates++; return; }
  var invalid=UF_validateLocal(platform, username);
  if(invalid) {
    if(!UF.invalidCache[key]) { UF.invalidCache[key]=true; UF_appendCache('invalid_usernames.tsv', platform, username, 'INVALID_RULE', invalid); }
    UF.counters.invalid++;
    UF_enqueueRow(platform, username, 'INVALID_RULE', invalid, 'Local syntax rule gate', UF_nowMs()-start, 0);
    return;
  }
  if(UF.validCache[key]) {
    UF.counters.valid++;
    UF_enqueueRow(platform, username, 'VALID_VERIFIED', 'Trusted cache/provider says available', 'Verified cache', UF_nowMs()-start, 99);
    UF_maybeLogVerified(platform, username, 'Verified cache', UF_nowMs()-start, 99);
    return;
  }
  if(UF.takenCache[key]) {
    UF.counters.taken++;
    UF_enqueueRow(platform, username, 'TAKEN_VERIFIED', 'Trusted cache/provider says taken', 'Verified taken cache', UF_nowMs()-start, 0);
    return;
  }
  UF.counters.unknown++;
  var mode = UF_id('providerMode').value;
  if(mode==='official-provider'){
    UF_enqueueProviderCandidate(platform, username);
    return;
  }
  // In verified-cache/import mode, unknown candidates are not displayed as results because they are not true checks.
};

function UF_enqueueProviderCandidate(platform, username){
  if(!UF.fso.FileExists(UF.providerAdapter)){
    if(!UF.providerMissingWarned){
      UF.providerMissingWarned = true;
      UF_log('WARN','Official Provider Adapter missing. Real VALID/TAKEN checks cannot run. Install providers\\OfficialProvider.ps1 or import trusted CSV.');
      UF_diagnoseProvider();
    }
    return;
  }
  UF.providerQueue.push({platform:platform, username:username});
  if(UF.providerQueue.length >= UF.providerBatchSize) UF_flushProviderBatch(false);
}

function UF_flushProviderBatch(force){
  try {
    if(UF.providerQueue.length < 1) return;
    if(UF_objCount(UF.providerPendingFiles) >= UF.providerMaxPending && !force) return;
    if(!UF.fso.FileExists(UF.providerGateway)){ UF_log('ERROR','Provider gateway missing: '+UF.providerGateway); return; }
    var take = Math.min(UF.providerBatchSize, UF.providerQueue.length);
    var batch=[];
    for(var i=0;i<take;i++) batch.push(UF.providerQueue.shift());
    UF.providerSeq++;
    var id = 'batch_' + (new Date().getTime()) + '_' + UF.providerSeq;
    var batchPath = UF.providerInbox + '\\' + id + '.tsv';
    var resultPath = UF.providerOut + '\\' + id + '.result.tsv';
    var t='Platform\tUsername\r\n';
    for(var j=0;j<batch.length;j++) t += batch[j].platform + '\t' + batch[j].username + '\r\n';
    UF_writeText(batchPath, t);
    UF.providerPendingFiles[resultPath] = true;
    UF.counters.predicted++;
    var ps = UF.shell.ExpandEnvironmentStrings('%SystemRoot%') + '\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
    var cmd = UF_quoteArg(ps) + ' -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ' + UF_quoteArg(UF.providerGateway) + ' -BatchFile ' + UF_quoteArg(batchPath) + ' -ResultFile ' + UF_quoteArg(resultPath) + ' -ProviderFile ' + UF_quoteArg(UF.providerAdapter) + ' -LogFile ' + UF_quoteArg(UF.providerLogFile);
    UF.shell.Run(cmd, 0, false);
    if(UF.providerSeq % 10 === 1) UF_log('OK','Provider batch queued: '+id+' candidates='+take);
  } catch(e){ UF_log('ERROR','Provider batch queue failed: '+UF_err(e)); UF_crash('Provider batch queue failed: '+UF_err(e)); }
}

function UF_pollProviderResults(){
  try {
    var processedAny=false;
    var folder = UF.fso.GetFolder(UF.providerOut);
    var files = new Enumerator(folder.Files);
    for(; !files.atEnd(); files.moveNext()){
      var file = files.item();
      var path = String(file.Path);
      if(path.toLowerCase().indexOf('.result.tsv') < 0) continue;
      var text = UF_readText(path);
      var lines=text.split(/\r?\n/);
      var valid=0,taken=0,invalid=0,unknown=0;
      for(var i=0;i<lines.length;i++){
        var line=lines[i]; if(!line || /^\s*platform\s*\t/i.test(line)) continue;
        var p=line.split('\t'); if(p.length<3) continue;
        var platform=UF_cleanPlatform(p[0]), username=UF_trim(p[1]), status=UF_trim(p[2]).toUpperCase();
        var source=p.length>3?UF_trim(p[3]):'Official provider';
        var latency=p.length>4?parseInt(p[4],10):0; if(isNaN(latency)) latency=0;
        var score=p.length>5?parseInt(p[5],10):99; if(isNaN(score)) score=99;
        var reason=p.length>6?UF_trim(p[6]):'Provider result';
        var key=UF_key(platform,username);
        UF.checkedCache[key]=true; UF_appendCache('checked_usernames.tsv', platform, username, status, source);
        if(status==='VALID_VERIFIED' || status==='VALID' || status==='AVAILABLE' || status==='FREE'){
          if(!UF.validCache[key]) { UF.validCache[key]=true; UF_appendCache('verified_available_usernames.tsv', platform, username, 'VALID_VERIFIED', source); }
          valid++; UF.counters.valid++; UF_enqueueRow(platform, username, 'VALID_VERIFIED', reason || 'Provider verified available', source, latency, score); UF_maybeLogVerified(platform, username, source, latency, score);
        } else if(status==='TAKEN_VERIFIED' || status==='TAKEN' || status==='UNAVAILABLE' || status==='USED'){
          if(!UF.takenCache[key]) { UF.takenCache[key]=true; UF_appendCache('taken_usernames.tsv', platform, username, 'TAKEN_VERIFIED', source); }
          taken++; UF.counters.taken++; UF_enqueueRow(platform, username, 'TAKEN_VERIFIED', reason || 'Provider verified taken', source, latency, 0);
        } else if(status==='INVALID_RULE' || status==='INVALID'){
          if(!UF.invalidCache[key]) { UF.invalidCache[key]=true; UF_appendCache('invalid_usernames.tsv', platform, username, 'INVALID_RULE', source); }
          invalid++; UF.counters.invalid++; UF_enqueueRow(platform, username, 'INVALID_RULE', reason || 'Provider/local rule invalid', source, latency, 0);
        } else {
          unknown++;
        }
      }
      try { delete UF.providerPendingFiles[path]; } catch(_e){}
      try { UF.fso.DeleteFile(path, true); } catch(_e2){}
      if(valid || taken || invalid || unknown) UF_log('OK','Provider result processed: valid='+valid+' taken='+taken+' invalid='+invalid+' unknown='+unknown);
      processedAny=true;
    }
    if(processedAny) { UF_refreshCacheView(); UF_updateCards(); }
  } catch(e){ /* avoid log spam while folder is empty/locked */ }
}

var UF_startEngine_V19 = UF_startEngine;
UF_startEngine = function(){
  if(UF.running) { UF_log('INFO', 'Engine already running.'); return; }
  UF_saveSettings();
  UF.providerMissingWarned=false;
  var mode = UF_id('providerMode').value;
  if(mode==='official-provider'){
    if(!UF.fso.FileExists(UF.providerGateway)){
      UF_log('ERROR','Provider gateway missing; cannot perform real checks.'); UF_diagnoseProvider(); return;
    }
    if(!UF.fso.FileExists(UF.providerAdapter)){
      UF_log('ERROR','Official Provider Adapter missing. Engine not started because true VALID/TAKEN checks require a trusted provider.');
      UF_id('statusText').innerText='Provider fehlt — keine echten Checks möglich. Importiere CSV oder installiere OfficialProvider.ps1.';
      UF_diagnoseProvider();
      return;
    }
  }
  UF.running=true;
  UF.noPlatformWarned=false;
  UF.lastGenerated=UF.counters.generated; UF.lastRateMs=UF_nowMs();
  try { UF_id('btnStartTop').disabled=true; } catch(e){}
  UF_log('OK','True Verify pipeline started. Mode='+mode+', workers='+UF_num('workers')+', checks/worker='+UF_num('checksWorker')+', safe cap='+UF_num('safeCap')+', budget='+UF_num('budgetMs')+'ms.');
  UF_id('statusText').innerText='True Verify running — only VALID_VERIFIED / TAKEN_VERIFIED / INVALID_RULE are shown.';
  if(!UF.providerPollTimer) UF.providerPollTimer = window.setInterval(UF_pollProviderResults, 600);
  UF_tickEngine();
};

var UF_stopEngine_V19 = UF_stopEngine;
UF_stopEngine = function(){
  try { UF_flushProviderBatch(true); } catch(e){}
  UF_stopEngine_V19();
};

var UF_tickEngine_V19 = UF_tickEngine;
UF_tickEngine = function(){
  if(!UF.running) return;
  try {
    var platforms=UF_getPlatforms();
    var minLen=UF_num('minLen'), maxLen=UF_num('maxLen');
    if(maxLen < minLen) { var tmp=minLen; minLen=maxLen; maxLen=tmp; }
    platforms=UF_allowedPlatformsForLen(platforms, minLen, maxLen);
    if(platforms.length<1){
      if(!UF.noPlatformWarned) { UF_log('WARN', 'No selected platform has a possible length range. Change length or platforms.'); UF.noPlatformWarned=true; }
      UF.tickTimer = window.setTimeout(UF_tickEngine, 500); return;
    }
    UF.noPlatformWarned=false;
    var workers=Math.max(1, Math.min(2048, UF_num('workers')));
    var checks=Math.max(1, Math.min(1000, UF_num('checksWorker')));
    var cap=Math.max(100, Math.min(100000, UF_num('safeCap')));
    var target=Math.min(cap, workers*checks);
    var budget=Math.max(4, Math.min(80, UF_num('budgetMs')));
    var endTime=UF_nowMs()+budget;
    var processed=0;
    while(processed < target && UF_nowMs() < endTime){
      var p=platforms[UF_randomInt(0,platforms.length-1)];
      var u=UF_makeUsername(p, minLen, maxLen);
      UF_processCandidate(p,u);
      processed++;
      if(UF.providerQueue.length >= UF.providerBatchSize) UF_flushProviderBatch(false);
    }
    if(processed===0){ var pp=platforms[UF_randomInt(0,platforms.length-1)]; UF_processCandidate(pp, UF_makeUsername(pp, minLen, maxLen)); }
    UF_flushProviderBatch(false);
    UF_pollProviderResults();
  } catch(e) { UF_log('ERROR', 'True Verify tick failed: ' + UF_err(e)); UF_crash('True Verify tick failed: ' + UF_err(e)); }
  UF.tickTimer = window.setTimeout(UF_tickEngine, Math.max(0, Math.min(500, UF_num('sleepMs'))));
};

var UF_updateCards_V19 = UF_updateCards;
UF_updateCards = function(){
  UF_updateCards_V19();
  try { UF_id('cardProvider').innerText = UF_providerStatusShort(); } catch(e){}
};

var UF_showTab_V19 = UF_showTab;
UF_showTab = function(name){
  var names=['results','valid','taken','log','contract','diagnostics','provider'];
  for(var i=0;i<names.length;i++){
    var el=UF_id('tab_'+names[i]); if(el) el.className='tabBody';
  }
  var target=UF_id('tab_'+name); if(target) target.className='tabBody visible';
};

var UF_runSelfDiagnostics_V19 = UF_runSelfDiagnostics;
UF_runSelfDiagnostics = function(){
  try { UF_runSelfDiagnostics_V19(); } catch(e){}
  UF_diagnoseProvider();
};

var UF_writeImportTemplate_V19 = UF_writeImportTemplate;
UF_writeImportTemplate = function(){
  var path=UF_cachePath('verify_import.csv');
  var text='Platform,Username,Status,Source,LatencyMs,Score\r\nDiscord,snoxy_test,VALID_VERIFIED,Manual proof or allowed provider,120,99\r\nTikTok,abc,TAKEN_VERIFIED,Official allowed provider,88,0\r\nInstagram,x_7,INVALID_RULE,Local syntax rule,0,0\r\n';
  UF_writeText(path,text); UF_log('OK','V23 import template created: '+path); UF.shell.Run('notepad.exe '+UF_quoteArg(path),1,false);
};


/* =====================================================================================
   V23 COMPLIANT VERIFY SAFE QUALITY PATCH
   - safer active local trusted provider installed by default
   - better boot status, diagnostics, and no fake live platform claims
   - more helpful Discord/provider status messages
   ===================================================================================== */
(function(){
  var oldBoot = UF_boot;
  UF_boot = function(){
    oldBoot();
    try {
      UF_id('statusText').innerText = 'Ready — local trusted provider installed. Import proof CSV or connect an allowed official provider for real VALID/TAKEN checks.';
      UF_log('OK','V23 quality patch active: robust installer, active Local Trusted DB Provider, true-only results, Discord Broker diagnostics.');
    } catch(e){}
  };
  var oldProviderStatus = UF_providerStatusShort;
  UF_providerStatusShort = function(){
    try {
      if(!UF.providerGateway || !UF.fso.FileExists(UF.providerGateway)) return 'gateway missing';
      if(UF_id('providerMode').value !== 'official-provider') return UF_id('providerMode').value;
      if(!UF.fso.FileExists(UF.providerAdapter)) return 'adapter missing';
      return 'ready';
    } catch(e){ return oldProviderStatus ? oldProviderStatus() : 'check failed'; }
  };
  var oldDiag = UF_diagnoseProvider;
  UF_diagnoseProvider = function(){
    oldDiag();
    try {
      var t = UF_id('providerText').value;
      t += '\r\n\r\nV23 ACTIVE PROVIDER INFO:\r\n';
      t += 'A safe Local Trusted Database Provider is installed as OfficialProvider.ps1.\r\n';
      t += 'It performs exact lookups against trusted_verify_database.csv and app TSV caches.\r\n';
      t += 'It never performs hidden social-media scraping. Unknown names remain UNKNOWN_UNVERIFIED.\r\n';
      t += 'Trusted DB CSV path: ' + UF_cachePath('trusted_verify_database.csv') + '\r\n';
      UF_id('providerText').value = t;
    } catch(e){}
  };
})();


/* =====================================================================================
   V23 COMPLIANT VERIFY SAFE PATCH
   Goal: the app focuses on the only reliable job: exact username truth state.
   It adds a synchronous Single TrueCheck panel, better provider status, trusted-db helpers,
   and clearer counters. No hidden social-media scraping is added.
   ===================================================================================== */
(function(){
  UF.version = 'V23 COMPLIANT VERIFY SAFE';

  UF_setSingleStatus = function(text, cls){
    try { var el=UF_id('singleStatus'); el.className='singleStatus '+(cls||''); el.innerText=text; } catch(e){}
  };
  UF_singlePlatform = function(){ try { return UF_cleanPlatform(UF_id('singlePlatform').value); } catch(e){ return 'Discord'; } };
  UF_singleUsername = function(){ try { return UF_trim(UF_id('singleUsername').value); } catch(e){ return ''; } };
  UF_statusCss = function(status){
    status = String(status).toUpperCase();
    if(status==='VALID_VERIFIED') return 'valid';
    if(status==='TAKEN_VERIFIED') return 'taken';
    if(status==='INVALID_RULE') return 'invalid';
    return 'unknown';
  };
  UF_addTrustedDbLine = function(platform, username, status, source, reason){
    try {
      var path = UF_cachePath('trusted_verify_database.csv');
      if(!UF.fso.FileExists(path)) UF_writeText(path, 'Platform,Username,Status,Source,Reason\r\n');
      var line = UF_csvEscape(platform)+','+UF_csvEscape(username)+','+UF_csvEscape(status)+','+UF_csvEscape(source||'manual proof')+','+UF_csvEscape(reason||'Manually marked in V23 UI')+'\r\n';
      UF_appendText(path,line);
    } catch(e){ UF_log('WARN','Could not update trusted DB CSV: '+UF_err(e)); }
  };
  UF_markSingle = function(status){
    var platform=UF_singlePlatform(), username=UF_singleUsername();
    if(!username){ UF_setSingleStatus('Bitte zuerst einen Username eingeben.', 'invalid'); return; }
    var invalid=UF_validateLocal(platform,username);
    if(invalid && status!=='INVALID_RULE') { UF_setSingleStatus('Kann nicht als VALID/TAKEN markiert werden: INVALID_RULE — '+invalid, 'invalid'); return; }
    var key=UF_key(platform,username);
    if(status==='VALID_VERIFIED'){
      UF.validCache[key]=true; UF_appendCache('verified_available_usernames.tsv', platform, username, 'VALID_VERIFIED', 'manual V23 mark');
      UF_addTrustedDbLine(platform,username,'VALID_VERIFIED','manual V23 mark','Manually verified available by user');
      UF.counters.valid++; UF_enqueueRow(platform,username,'VALID_VERIFIED','Manually verified available','manual V23 mark',0,99); UF_maybeLogVerified(platform,username,'manual V23 mark',0,99);
    } else if(status==='TAKEN_VERIFIED'){
      UF.takenCache[key]=true; UF_appendCache('taken_usernames.tsv', platform, username, 'TAKEN_VERIFIED', 'manual V23 mark');
      UF_addTrustedDbLine(platform,username,'TAKEN_VERIFIED','manual V23 mark','Manually verified taken by user');
      UF.counters.taken++; UF_enqueueRow(platform,username,'TAKEN_VERIFIED','Manually verified taken','manual V23 mark',0,0);
    } else {
      UF.invalidCache[key]=true; UF_appendCache('invalid_usernames.tsv', platform, username, 'INVALID_RULE', 'manual V23 mark');
      UF_addTrustedDbLine(platform,username,'INVALID_RULE','manual V23 mark','Manually marked invalid by user');
      UF.counters.invalid++; UF_enqueueRow(platform,username,'INVALID_RULE','Manually marked invalid','manual V23 mark',0,0);
    }
    UF.checkedCache[key]=true; UF_appendCache('checked_usernames.tsv', platform, username, status, 'manual V23 mark');
    UF_refreshCacheView(); UF_updateCards(); UF_setSingleStatus(status+' saved for '+platform+'/'+username+'\nSource: manual V23 mark', UF_statusCss(status));
  };
  UF_checkSingleNow = function(){
    try {
      var platform=UF_singlePlatform(), username=UF_singleUsername();
      if(!username){ UF_setSingleStatus('Bitte Username eingeben.', 'invalid'); return; }
      var start=UF_nowMs();
      var invalid=UF_validateLocal(platform, username);
      if(invalid){
        var k0=UF_key(platform,username); UF.invalidCache[k0]=true; UF_appendCache('invalid_usernames.tsv', platform, username, 'INVALID_RULE', invalid);
        UF.counters.invalid++; UF_enqueueRow(platform,username,'INVALID_RULE',invalid,'Local syntax rule',UF_nowMs()-start,0); UF_refreshCacheView(); UF_updateCards();
        UF_setSingleStatus('INVALID_RULE\nPlatform: '+platform+'\nUsername: '+username+'\nReason: '+invalid, 'invalid');
        return;
      }
      var key=UF_key(platform,username);
      if(UF.validCache[key]){ UF_enqueueRow(platform,username,'VALID_VERIFIED','Trusted cache hit','Verified cache',0,99); UF_setSingleStatus('VALID_VERIFIED\nPlatform: '+platform+'\nUsername: '+username+'\nSource: verified cache', 'valid'); UF_maybeLogVerified(platform,username,'Verified cache',0,99); return; }
      if(UF.takenCache[key]){ UF_enqueueRow(platform,username,'TAKEN_VERIFIED','Trusted taken cache hit','Taken cache',0,0); UF_setSingleStatus('TAKEN_VERIFIED\nPlatform: '+platform+'\nUsername: '+username+'\nSource: taken cache', 'taken'); return; }
      // Run provider synchronously for exactly one username. This gives immediate truth if an allowed provider/local trusted DB has proof.
      if(!UF.fso.FileExists(UF.providerGateway)){ UF_setSingleStatus('UNKNOWN_UNVERIFIED\nProvider gateway missing. No real check possible.', 'unknown'); return; }
      if(!UF.fso.FileExists(UF.providerAdapter)){ UF_setSingleStatus('UNKNOWN_UNVERIFIED\nProvider adapter missing. Install allowed OfficialProvider.ps1 or import trusted CSV.', 'unknown'); return; }
      var id='single_'+(new Date().getTime());
      var batchPath=UF.providerInbox+'\\'+id+'.tsv';
      var resultPath=UF.providerOut+'\\'+id+'.result.tsv';
      UF_writeText(batchPath,'Platform\tUsername\r\n'+platform+'\t'+username+'\r\n');
      var ps=UF.shell.ExpandEnvironmentStrings('%SystemRoot%')+'\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
      var cmd=UF_quoteArg(ps)+' -NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+UF_quoteArg(UF.providerGateway)+' -BatchFile '+UF_quoteArg(batchPath)+' -ResultFile '+UF_quoteArg(resultPath)+' -ProviderFile '+UF_quoteArg(UF.providerAdapter)+' -LogFile '+UF_quoteArg(UF.providerLogFile);
      UF_setSingleStatus('Checking '+platform+'/'+username+' via provider...','unknown');
      UF.shell.Run(cmd,0,true);
      if(!UF.fso.FileExists(resultPath)){ UF_setSingleStatus('UNKNOWN_UNVERIFIED\nProvider returned no result file. See Provider Log.', 'unknown'); UF_openProviderLog(); return; }
      var text=UF_readText(resultPath), lines=text.split(/\r?\n/), found=null;
      for(var i=0;i<lines.length;i++){ var line=lines[i]; if(!line || /^\s*platform\s*\t/i.test(line)) continue; var parts=line.split('\t'); if(parts.length>=3){ found=parts; break; } }
      try { UF.fso.DeleteFile(resultPath,true); } catch(_e){}
      if(!found){ UF_setSingleStatus('UNKNOWN_UNVERIFIED\nProvider output was empty. See Provider Log.', 'unknown'); return; }
      var status=UF_trim(found[2]).toUpperCase();
      var source=found.length>3?UF_trim(found[3]):'Provider';
      var latency=found.length>4?parseInt(found[4],10):UF_nowMs()-start; if(isNaN(latency)) latency=UF_nowMs()-start;
      var score=found.length>5?parseInt(found[5],10):0; if(isNaN(score)) score=0;
      var reason=found.length>6?UF_trim(found[6]):'Provider result';
      UF.checkedCache[key]=true; UF_appendCache('checked_usernames.tsv', platform, username, status, source);
      if(status==='VALID_VERIFIED' || status==='VALID' || status==='AVAILABLE' || status==='FREE'){
        UF.validCache[key]=true; UF_appendCache('verified_available_usernames.tsv', platform, username, 'VALID_VERIFIED', source); UF.counters.valid++; UF_enqueueRow(platform,username,'VALID_VERIFIED',reason,source,latency,score||99); UF_maybeLogVerified(platform,username,source,latency,score||99); UF_setSingleStatus('VALID_VERIFIED\nPlatform: '+platform+'\nUsername: '+username+'\nSource: '+source+'\nReason: '+reason, 'valid');
      } else if(status==='TAKEN_VERIFIED' || status==='TAKEN' || status==='UNAVAILABLE' || status==='USED'){
        UF.takenCache[key]=true; UF_appendCache('taken_usernames.tsv', platform, username, 'TAKEN_VERIFIED', source); UF.counters.taken++; UF_enqueueRow(platform,username,'TAKEN_VERIFIED',reason,source,latency,0); UF_setSingleStatus('TAKEN_VERIFIED\nPlatform: '+platform+'\nUsername: '+username+'\nSource: '+source+'\nReason: '+reason, 'taken');
      } else if(status==='INVALID_RULE' || status==='INVALID'){
        UF.invalidCache[key]=true; UF_appendCache('invalid_usernames.tsv', platform, username, 'INVALID_RULE', source); UF.counters.invalid++; UF_enqueueRow(platform,username,'INVALID_RULE',reason,source,latency,0); UF_setSingleStatus('INVALID_RULE\nPlatform: '+platform+'\nUsername: '+username+'\nSource: '+source+'\nReason: '+reason, 'invalid');
      } else {
        UF.counters.unknown++; UF_setSingleStatus('UNKNOWN_UNVERIFIED\nPlatform: '+platform+'\nUsername: '+username+'\nSource: '+source+'\nReason: '+reason+'\n\nDas bedeutet: Kein Proof in Import/Trusted DB/Provider.', 'unknown');
      }
      UF_refreshCacheView(); UF_updateCards();
    } catch(e){ UF_setSingleStatus('Check failed: '+UF_err(e), 'invalid'); UF_log('ERROR','Single TrueCheck failed: '+UF_err(e)); UF_crash('Single TrueCheck failed: '+UF_err(e)); }
  };

  var oldBoot = UF_boot;
  UF_boot = function(){
    oldBoot();
    try {
      UF_id('statusText').innerText='V23 ready — nutze Single TrueCheck fuer genau einen Namen oder importiere trusted CSV fuer echte Valid/Taken-Ergebnisse.';
      UF_log('OK','V23 Compliant Verify loaded: Single TrueCheck, local trusted provider, true-only Discord logging, no fake availability claims.');
      try { UF_id('singlePlatform').value = 'Discord'; } catch(e){}
    } catch(e){}
  };

  var oldDefault = UF_defaultSettings;
  UF_defaultSettings = function(){
    var s=oldDefault();
    s.autoStart=false;
    s.providerMode='official-provider';
    s.workers=512; s.checksWorker=40; s.safeCap=25000; s.budgetMs=18; s.sleepMs=0; s.maxRows=2500;
    return s;
  };

  var oldUpdateCards = UF_updateCards;
  UF_updateCards = function(){
    oldUpdateCards();
    try { UF_id('cardUnknown').innerText = UF_fmt(UF.counters.valid + UF.counters.taken + UF.counters.invalid); } catch(e){}
  };

  var oldContract = UF_bindContractText;
  UF_bindContractText = function(){
    try { oldContract(); } catch(e){}
    try {
      var t = UF_id('contractText').value;
      t += '\r\n\r\nV23 COMPLIANT VERIFY ADDITION:\r\n';
      t += 'The main feature is Single TrueCheck: enter one platform+username and get INVALID_RULE, VALID_VERIFIED, TAKEN_VERIFIED, or UNKNOWN_UNVERIFIED.\r\n';
      t += 'UNKNOWN_UNVERIFIED is an honest answer: no trusted proof exists in your import/provider/cache.\r\n';
      t += 'The app cannot create 100% truth from guessing. It needs proof data or an allowed official provider.\r\n';
      UF_id('contractText').value = t;
    } catch(e){}
  };
})();


/* V23 COMPLIANT VERIFY SAFE additions
   Browser profile opening is intentionally manual-only. Automated multi-worker browser probing
   would be scraping/enumeration and is not implemented. */
(function(){
  function safeUser(u){ return String(u||'').replace(/^@+/,'').replace(/[^A-Za-z0-9._-]/g,'').substring(0,64); }
  window.UF_profileUrlFor = function(platform, username){
    var u=safeUser(username);
    if(!u) return '';
    platform=String(platform||'').toLowerCase();
    if(platform==='instagram') return 'https://www.instagram.com/' + encodeURIComponent(u) + '/';
    if(platform==='tiktok') return 'https://www.tiktok.com/@' + encodeURIComponent(u);
    if(platform==='telegram') return 'https://t.me/' + encodeURIComponent(u);
    if(platform==='snapchat') return 'https://www.snapchat.com/add/' + encodeURIComponent(u);
    if(platform==='discord') return '';
    return '';
  };
  window.UF_updateProfileUrlPreview = function(){
    try{
      var p = UF_singlePlatform ? UF_singlePlatform() : (UF_id('singlePlatform').value || 'Discord');
      var u = UF_singleUsername ? UF_singleUsername() : UF_id('singleUsername').value;
      var url = UF_profileUrlFor(p,u);
      var text = url || 'Discord hat keine öffentliche Username-Availability-URL. Nutze Import/Provider/Manual Proof.';
      if(UF_id('profileUrlPreview')) UF_id('profileUrlPreview').innerText = 'URL preview: ' + text;
      return url;
    }catch(e){ return ''; }
  };
  window.UF_openSingleInBrowser = function(){
    try{
      var p=UF_singlePlatform(), u=UF_singleUsername();
      var invalid=UF_validateLocal(p,u);
      if(!u){ alert('Bitte zuerst einen Username eingeben.'); return; }
      if(invalid){ UF_setSingleStatus('INVALID_RULE\n'+p+'/'+u+'\n'+invalid,'invalid'); return; }
      var url=UF_profileUrlFor(p,u);
      if(!url){ alert('Für '+p+' gibt es keine zuverlässige öffentliche Username-Check-URL in dieser App. Nutze Trusted CSV/Provider oder manuelle Bestätigung.'); return; }
      UF_log('INFO','Manual browser proof opened: '+p+'/'+u+' -> '+url);
      UF.shell.Run('cmd /c start "" ' + UF_quoteArg(url), 0, false);
      UF_setSingleStatus('Browser opened for manual proof. Danach nur bewusst Mark VALID/TAKEN drücken, wenn du es wirklich geprüft hast.\n'+url,'unknown');
      UF_updateProfileUrlPreview();
    }catch(e){ UF_log('ERROR','Open browser proof failed: '+UF_err(e)); }
  };
  window.UF_copySingleProfileUrl = function(){
    try{
      var url=UF_updateProfileUrlPreview();
      if(!url){ alert('Keine Profil-URL verfügbar.'); return; }
      if(window.clipboardData){ window.clipboardData.setData('Text', url); UF_log('OK','Profile URL copied.'); }
      else { alert(url); }
    }catch(e){ alert('Copy failed: '+e.message); }
  };
  var oldBootV23 = UF_boot;
  UF_boot = function(){
    oldBootV23();
    try{
      UF.version='V23';
      UF_id('statusText').innerText='V23 ready — echte VALID/TAKEN nur über Trusted DB, Import oder erlaubten Provider. Browser-Öffnen ist manuell, nicht automatisiert.';
      UF_log('OK','V23 Compliant Verify loaded. Automated browser scraping and bot-token enumeration are disabled by design.');
      var p=UF_id('singleUsername'); if(p){ p.onkeyup=UF_updateProfileUrlPreview; p.onchange=UF_updateProfileUrlPreview; }
      var sp=UF_id('singlePlatform'); if(sp){ sp.onchange=UF_updateProfileUrlPreview; }
      UF_updateProfileUrlPreview();
    }catch(e){}
  };
  var oldContractV23 = UF_bindContractText;
  UF_bindContractText = function(){
    try{ oldContractV23(); }catch(e){}
    try{
      var t=UF_id('contractText').value;
      t+='\r\n\r\nV23 COMPLIANT VERIFY ADDITION:\r\n';
      t+='- The app does not run automated browser workers against Instagram/TikTok/Telegram/Snapchat/Discord.\r\n';
      t+='- Browser proof is manual-only: open one page, inspect, then mark VALID/TAKEN yourself.\r\n';
      t+='- Discord bot tokens are not used for username enumeration. Only official/allowed provider adapters may return VALID_VERIFIED/TAKEN_VERIFIED.\r\n';
      t+='- This prevents fake hits, account blocks, rate-limit abuse, and unstable scraping results.\r\n';
      UF_id('contractText').value=t;
    }catch(e){}
  };
})();
