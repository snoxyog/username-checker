@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" exit /b 11
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-UsernameFinder.ps1"
exit /b %ERRORLEVEL%
