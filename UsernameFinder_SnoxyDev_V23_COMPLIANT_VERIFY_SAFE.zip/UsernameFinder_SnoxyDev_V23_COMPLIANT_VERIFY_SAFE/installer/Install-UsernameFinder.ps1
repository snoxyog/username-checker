# Username Finder V23 COMPLIANT VERIFY SAFE
# Robust user-scope installer: no admin, no hidden downloads, no SDK. Requirements are checked and logged.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$AppName = 'Username Finder'
$Version = 'V23_COMPLIANT_VERIFY_SAFE'
$Root = Join-Path $env:LOCALAPPDATA 'SnoxyDev\UsernameFinder'
$Versions = Join-Path $Root 'versions'
$Data = Join-Path $Root 'data'
$Log = Join-Path $Root 'install.log'
$SelfTest = Join-Path $Root 'selftest.log'
$InstallLock = Join-Path $Root 'install.lock'

function Ensure-Dir([string]$Path){ if(-not [IO.Directory]::Exists($Path)){ [IO.Directory]::CreateDirectory($Path) | Out-Null } }
function Write-InstallLog([string]$Level,[string]$Message){
  try { Ensure-Dir $Root; Add-Content -LiteralPath $Log -Encoding UTF8 -Value ('[{0:yyyy-MM-ddTHH:mm:ss.fff}] [{1}] {2}' -f (Get-Date),$Level,$Message) } catch {}
  $color = 'Gray'; if($Level -eq 'OK'){$color='Green'} elseif($Level -eq 'WARN'){$color='Yellow'} elseif($Level -eq 'ERROR'){$color='Red'} elseif($Level -eq 'INFO'){$color='Cyan'}
  try { Write-Host ("[$Level] $Message") -ForegroundColor $color } catch { Write-Output "[$Level] $Message" }
}
function Test-CanWrite([string]$Folder){ Ensure-Dir $Folder; $t=Join-Path $Folder ('write_test_{0}.tmp' -f ([Guid]::NewGuid().ToString('N'))); [IO.File]::WriteAllText($t,'ok',[Text.UTF8Encoding]::new($false)); [IO.File]::Delete($t) }
function Resolve-Exe([string]$Path){ if([IO.File]::Exists($Path)){ return $Path } return $null }
function Stop-OldAppProcesses{
  Write-InstallLog INFO 'Schliesse alte Username-Finder-HTA-Prozesse des aktuellen Benutzers, falls vorhanden.'
  try {
    $procs = Get-CimInstance Win32_Process -Filter "Name='mshta.exe'" -ErrorAction Stop | Where-Object { $_.CommandLine -match 'UsernameFinder\.hta' }
    foreach($p in $procs){ try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; Write-InstallLog OK "Alter Prozess beendet: PID=$($p.ProcessId)" } catch { Write-InstallLog WARN "Alter Prozess konnte nicht beendet werden: PID=$($p.ProcessId) $($_.Exception.Message)" } }
  } catch { Write-InstallLog WARN "Prozess-Scan uebersprungen: $($_.Exception.Message)" }
}
function Copy-TreeRobust([string]$From,[string]$To){
  if(-not [IO.Directory]::Exists($From)){ Write-InstallLog WARN "Optionaler Ordner fehlt: $From"; return }
  Ensure-Dir $To
  $sourceFull = [IO.Path]::GetFullPath($From).TrimEnd('\')
  $files = [IO.Directory]::EnumerateFiles($sourceFull,'*',[IO.SearchOption]::AllDirectories)
  $copied = 0; $warn = 0
  foreach($src in $files){
    $rel = $src.Substring($sourceFull.Length).TrimStart('\')
    $dst = Join-Path $To $rel
    Ensure-Dir (Split-Path -Parent $dst)
    $ok = $false
    for($i=1; $i -le 8 -and -not $ok; $i++){
      try { [IO.File]::Copy($src,$dst,$true); try { Unblock-File -LiteralPath $dst -ErrorAction SilentlyContinue } catch {}; $ok=$true; $copied++ }
      catch { Start-Sleep -Milliseconds (100*$i); if($i -eq 8){ $warn++; Write-InstallLog WARN "Datei konnte nicht kopiert werden: $rel :: $($_.Exception.Message)" } }
    }
  }
  Write-InstallLog OK "Kopiert: $From -> $To ($copied Dateien, Warnungen=$warn)"
}
function Write-LauncherFiles([string]$Target,[string]$Ver){
  $start = Join-Path $Root 'Start_UsernameFinder.cmd'
  $debug = Join-Path $Root 'Start_UsernameFinder_DEBUG.cmd'
  $vbs = Join-Path $Root 'Launch_UsernameFinder.vbs'
  $openLogs = Join-Path $Root 'Open_Logs.cmd'
  $repair = Join-Path $Root 'Repair_Install.cmd'
  $current = Join-Path $Root 'current_version.txt'
  Set-Content -LiteralPath $current -Encoding ASCII -Value $Ver
@"
@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set /p VER=<"%ROOT%current_version.txt"
set "APP=%ROOT%versions\%VER%\app\UsernameFinder.hta"
if not exist "%APP%" (
  echo App file not found: %APP%
  echo Start Repair_Install.cmd or reinstall from START_INSTALL.cmd
  pause
  exit /b 2
)
start "" "%SystemRoot%\System32\mshta.exe" "%APP%"
exit /b 0
"@ | Set-Content -LiteralPath $start -Encoding ASCII
@"
@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
set "ROOT=%~dp0"
set /p VER=<"%ROOT%current_version.txt"
set "APP=%ROOT%versions\%VER%\app\UsernameFinder.hta"
echo Debug start: %APP%
echo Logs:
echo   %ROOT%install.log
echo   %ROOT%selftest.log
echo   %ROOT%app.log
echo   %ROOT%crash.log
echo   %ROOT%webhook_results.log
echo   %ROOT%provider_gateway.log
echo.
"%SystemRoot%\System32\mshta.exe" "%APP%"
echo.
echo Wenn die App nicht sichtbar war, pruefe crash.log/app.log.
pause
"@ | Set-Content -LiteralPath $debug -Encoding ASCII
@"
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.Run Chr(34) & base & "\Start_UsernameFinder.cmd" & Chr(34), 0, False
"@ | Set-Content -LiteralPath $vbs -Encoding ASCII
@"
@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
start notepad "%ROOT%install.log"
start notepad "%ROOT%selftest.log"
start notepad "%ROOT%app.log"
start notepad "%ROOT%crash.log"
start notepad "%ROOT%webhook_results.log"
start notepad "%ROOT%provider_gateway.log"
"@ | Set-Content -LiteralPath $openLogs -Encoding ASCII
@"
@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
set "INSTALLER=$Target\installer\Install-UsernameFinder.ps1"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%INSTALLER%"
pause
"@ | Set-Content -LiteralPath $repair -Encoding ASCII
  Write-InstallLog OK 'Launcher, Debug-Tools und Repair-Dateien geschrieben.'
}
function Create-Shortcuts{
  try {
    $sh = New-Object -ComObject WScript.Shell
    $desktop = [Environment]::GetFolderPath('DesktopDirectory')
    $programs = $sh.SpecialFolders.Item('Programs')
    $menu = Join-Path $programs 'Snoxy.dev'
    Ensure-Dir $menu
    $targetWscript = Join-Path $env:WINDIR 'System32\wscript.exe'
    $launchVbs = Join-Path $Root 'Launch_UsernameFinder.vbs'
    foreach($shortcutPath in @((Join-Path $desktop 'Username Finder.lnk'), (Join-Path $menu 'Username Finder.lnk'))){
      $lnk = $sh.CreateShortcut($shortcutPath); $lnk.TargetPath = $targetWscript; $lnk.Arguments = '"' + $launchVbs + '"'; $lnk.WorkingDirectory = $Root; $lnk.Description = 'Username Finder V23 COMPLIANT VERIFY SAFE by Snoxy.dev'; $lnk.Save()
    }
    $lnk3 = $sh.CreateShortcut((Join-Path $menu 'Username Finder DEBUG.lnk')); $lnk3.TargetPath = Join-Path $Root 'Start_UsernameFinder_DEBUG.cmd'; $lnk3.WorkingDirectory = $Root; $lnk3.Description='Debug Launcher'; $lnk3.Save()
    Write-InstallLog OK 'Desktop- und Startmenue-Shortcuts erstellt.'
  } catch { Write-InstallLog WARN "Shortcuts konnten nicht vollstaendig erstellt werden: $($_.Exception.Message)" }
}
function Write-SelfTest([string]$Target,[string]$Mshta,[string]$Ps,[string]$Ver){
  $lines = New-Object System.Collections.Generic.List[string]
  $lines.Add('Username Finder V23 Selftest')
  $lines.Add('Time=' + (Get-Date).ToString('o'))
  $lines.Add('Version=' + $Ver)
  $lines.Add('Root=' + $Root)
  $lines.Add('Target=' + $Target)
  $lines.Add('mshta=' + $Mshta)
  $lines.Add('powershell=' + $Ps)
  $checks = @(
    ('app exists=' + (Test-Path -LiteralPath (Join-Path $Target 'app\UsernameFinder.hta'))),
    ('discord broker exists=' + (Test-Path -LiteralPath (Join-Path $Target 'app\tools\DiscordWebhookBroker.ps1'))),
    ('provider gateway exists=' + (Test-Path -LiteralPath (Join-Path $Target 'app\tools\ProviderGateway.ps1'))),
    ('local trusted provider exists=' + (Test-Path -LiteralPath (Join-Path $Target 'providers\OfficialProvider.ps1'))),
    ('fallback html exists=' + (Test-Path -LiteralPath (Join-Path $Target 'portable\UsernameFinder_Fallback.html'))),
    'data write test=OK'
  )
  foreach($c in $checks){ $lines.Add($c) }
  $lines | Set-Content -LiteralPath $SelfTest -Encoding UTF8
  Write-InstallLog OK 'Selftest geschrieben.'
}
function Start-App([string]$Target,[string]$Mshta){
  $app = Join-Path $Target 'app\UsernameFinder.hta'
  if(-not (Test-Path -LiteralPath $app)){ throw "App fehlt: $app" }
  Start-Process -FilePath $Mshta -ArgumentList ('"{0}"' -f $app) -WorkingDirectory (Split-Path -Parent $app) | Out-Null
  Start-Sleep -Milliseconds 500
  Write-InstallLog OK 'App-Startbefehl wurde ausgefuehrt.'
}
try {
  Ensure-Dir $Root; Ensure-Dir $Versions; Ensure-Dir $Data
  if(Test-Path -LiteralPath $InstallLock){ try { Remove-Item -LiteralPath $InstallLock -Force -ErrorAction SilentlyContinue } catch {} }
  New-Item -ItemType File -Path $InstallLock -Force | Out-Null
  Write-InstallLog INFO 'Username Finder V23 Setup gestartet: user-scope, keine Admin-Rechte, keine versteckten Downloads, keine SDKs.'
  Test-CanWrite $Root; Test-CanWrite $Data
  $Source = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
  Write-InstallLog INFO "Source: $Source"
  $Mshta = Resolve-Exe (Join-Path $env:WINDIR 'System32\mshta.exe')
  $Ps = Resolve-Exe (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
  if(-not $Ps){ throw 'Windows PowerShell 5.1 fehlt. Wird fuer Setup, Discord Broker und Provider Gateway benoetigt.' }
  if(-not $Mshta){ throw 'mshta.exe fehlt oder ist deaktiviert. Ohne Admin kann das Setup diese Windows-Komponente nicht heimlich aktivieren.' }
  Write-InstallLog OK "Requirements OK: mshta=$Mshta; powershell=$Ps"
  Stop-OldAppProcesses
  $ver = 'v23_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + $PID
  $Target = Join-Path $Versions $ver
  Ensure-Dir $Target
  foreach($d in 'app','providers','docs','tools','installer','portable'){ Ensure-Dir (Join-Path $Target $d) }
  foreach($d in 'app','providers','docs','tools','installer','portable'){ Copy-TreeRobust (Join-Path $Source $d) (Join-Path $Target $d) }
  Write-LauncherFiles -Target $Target -Ver $ver
  Create-Shortcuts
  Write-SelfTest -Target $Target -Mshta $Mshta -Ps $Ps -Ver $ver
  Start-App -Target $Target -Mshta $Mshta
  Write-InstallLog OK 'Setup abgeschlossen. App wurde gestartet.'
  Remove-Item -LiteralPath $InstallLock -Force -ErrorAction SilentlyContinue
  exit 0
} catch {
  Write-InstallLog ERROR $_.Exception.Message
  try { $_ | Out-String | Add-Content -LiteralPath $Log -Encoding UTF8 } catch {}
  try { Remove-Item -LiteralPath $InstallLock -Force -ErrorAction SilentlyContinue } catch {}
  exit 1
}
